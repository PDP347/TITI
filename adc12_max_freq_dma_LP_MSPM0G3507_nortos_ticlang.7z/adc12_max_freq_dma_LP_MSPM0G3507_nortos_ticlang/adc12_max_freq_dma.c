/*
 * TI MSPM0G3507 ADC双通道时域分析 + 高级定时器捕获相位测量
 * 固定频率版本 - 10kHz
 * 包含滤波、异常值检测等高级功能（移除频率估计）
 */

#include "ti_msp_dl_config.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* ADC configuration */
#define ADC_SAMPLE_SIZE (1000)
#define ADC_VREF (3.3f)
#define ADC_RESOLUTION (4096)
#define TIME_DOMAIN_SAMPLES (256)

/* 高级相位测量配置 */
#define TIMER_FREQ_HZ           32000000    // 定时器频率 32MHz
#define SIGNAL_FREQUENCY        10000.0f    // 固定信号频率 10kHz
#define MAX_TIMER_VALUE         0xFFFF      // 16位定时器最大值
#define MAX_OVERFLOW_COUNT      1000        // 最大溢出计数

/* 滤波和统计配置 */
#define PHASE_BUFFER_SIZE       10          // 相位缓冲区大小
#define PHASE_STABILITY_THRESHOLD  2.0f    // 相位稳定性阈值(度)
#define OUTLIER_THRESHOLD       10.0f       // 异常值阈值(度)
#define MOVING_AVG_ALPHA        0.3f        // 移动平均滤波系数

#define UART_BUFFER_SIZE        256

/* 数据结构定义 */
typedef struct {
    uint32_t capture_value;     // 捕获值
    uint32_t overflow_count;    // 溢出计数
    uint8_t captured;           // 捕获标志
} channel_data_t;

typedef struct {
    float phase_difference_deg;         // 相位差（度）
    float phase_difference_filtered;    // 滤波后的相位差
    float signal_frequency;             // 信号频率（固定10kHz）
    float phase_std_dev;                // 相位标准差
    uint32_t valid_samples;             // 有效样本数
    uint32_t outlier_count;             // 异常值计数
    uint8_t measurement_ready;          // 测量就绪标志
    uint8_t system_stable;              // 系统稳定标志
} phase_measurement_result_t;

/* ADC sample buffers */
uint16_t gADC0Samples[ADC_SAMPLE_SIZE];
uint16_t gADC1Samples[ADC_SAMPLE_SIZE];
volatile bool gCheckADC0;
volatile bool gCheckADC1;

/* 时域测量缓冲区和结果 */
float gTimeDomainSignal0[TIME_DOMAIN_SAMPLES];
float gTimeDomainSignal1[TIME_DOMAIN_SAMPLES];
volatile float gDCOffset0, gDCOffset1;
volatile float gAmplitude0, gAmplitude1;
volatile float gPeakToPeak0, gPeakToPeak1;

/* 高级相位测量变量 */
static channel_data_t ch0_data = {0};
static channel_data_t ch1_data = {0};
static volatile uint8_t phase_measurement_ready = 0;
static volatile uint32_t global_overflow_count = 0;

// 相位差计算结果
static float phase_difference_deg = 0.0f;
static float phase_difference_filtered = 0.0f;

// 相位差缓冲区用于均值滤波
static float phase_buffer[PHASE_BUFFER_SIZE];
static uint8_t phase_buffer_index = 0;
static uint8_t phase_buffer_full = 0;

// 滤波相关变量
static float phase_variance = 0.0f;
static float phase_std_dev = 0.0f;
static uint32_t valid_samples = 0;
static uint32_t outlier_count = 0;
static float last_valid_phase = 0.0f;

// 中断标志位
static volatile bool gCH0_Captured = false;
static volatile bool gCH1_Captured = false;
static volatile bool gTimer_Overflow = false;

char uart_buffer[UART_BUFFER_SIZE];

/* 函数声明 */
void UART_send_string(const char* str);
void configure_adc_dma(void);
void configure_timer_capture(void);
void perform_time_domain_analysis(void);
void prepare_time_domain_data(uint16_t* adc_samples, float* output, uint16_t offset);
float calculate_dc_offset(uint16_t* samples, uint16_t start, uint16_t count);
float calculate_amplitude(float* signal, uint16_t size);
float calculate_peak_to_peak(float* signal, uint16_t size);

// 高级相位测量函数
void MeasureDiff_Init(void);
void MeasureDiff_Reset(void);
void MeasureDiff_Process(void);
void MeasureDiff_GetResult(phase_measurement_result_t *result);
float MeasureDiff_GetPhaseDeg(void);
float MeasureDiff_GetFrequency(void);
uint8_t MeasureDiff_IsStable(void);
float MeasureDiff_GetStdDev(void);

// 私有函数
static float Calculate_Average_Phase(void);
static float Calculate_Weighted_Average_Phase(void);
static float Calculate_Phase_Variance(float mean);
static uint8_t Is_Phase_Outlier(float phase_value, float mean, float std_dev);
static float Get_Signal_Period_Us(void);
static float Apply_Moving_Average_Filter(float new_value, float old_value);
static void Process_CH0_Capture(void);
static void Process_CH1_Capture(void);
static void Process_Timer_Overflow(void);

void output_results(void);

int main(void)
{
    SYSCFG_DL_init();

    /* 初始化UART */
    UART_send_string("TI MSPM0G3507 Advanced Phase Measurement System\r\n");
    UART_send_string("ADC Time Domain + Advanced Timer Capture Phase Analysis\r\n");
    UART_send_string("Fixed Frequency: 10kHz\r\n");
    UART_send_string("Features: Filtering, Outlier Detection\r\n");
    UART_send_string("================================================\r\n");
    
    /* 配置ADC和DMA */
    configure_adc_dma();
    
    /* 初始化高级相位测量模块 */
    MeasureDiff_Init();
    
    /* 添加延时确保系统稳定 */
    DL_Common_delayCycles(100000);

    static bool adc0_ready = false;
    static bool adc1_ready = false;

    while (1) {
        /* ADC数据处理 */
        if (gCheckADC0) {
            gCheckADC0 = false;
            adc0_ready = true;
            
            DL_ADC12_setDMASamplesCnt(ADC12_0_INST, 1);
            DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
            DL_ADC12_startConversion(ADC12_0_INST);
        }
        
        if (gCheckADC1) {
            gCheckADC1 = false;
            adc1_ready = true;
            
            DL_ADC12_setDMASamplesCnt(ADC12_1_INST, 1);
            DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);
            DL_ADC12_startConversion(ADC12_1_INST);
        }
        
        // 当两路ADC都有新数据时，进行时域分析
        if (adc0_ready && adc1_ready) {
            perform_time_domain_analysis();
            
            adc0_ready = false;
            adc1_ready = false;
        }

        /* 高级相位测量处理 */
        // 处理CH0捕获事件
        if (gCH0_Captured) {
            gCH0_Captured = false;
            Process_CH0_Capture();
        }

        // 处理CH1捕获事件
        if (gCH1_Captured) {
            gCH1_Captured = false;
            Process_CH1_Capture();
        }

        // 处理定时器溢出事件
        if (gTimer_Overflow) {
            gTimer_Overflow = false;
            Process_Timer_Overflow();
        }

        // 高级相位测量处理
        if (phase_measurement_ready) {
            MeasureDiff_Process();
            
            // 输出所有测量结果
            output_results();
            
            // 添加测量间隔
            DL_Common_delayCycles(500000);
        }
        
        // 进入低功耗等待
        __WFE();
    }
}

/* 高级相位测量模块实现 */

/**
 * @brief 初始化相位测量模块
 */
void MeasureDiff_Init(void)
{
    // 清空相位缓冲区
    for(uint8_t i = 0; i < PHASE_BUFFER_SIZE; i++) {
        phase_buffer[i] = 0.0f;
    }
    
    phase_buffer_index = 0;
    phase_buffer_full = 0;
    valid_samples = 0;
    outlier_count = 0;
    last_valid_phase = 0.0f;
    
    // 重置测量标志
    MeasureDiff_Reset();
    
    // 配置定时器捕获
    configure_timer_capture();
    
    UART_send_string("Advanced Phase Measurement Module Initialized (10kHz Fixed)\r\n");
}

/**
 * @brief 重置相位测量状态
 */
void MeasureDiff_Reset(void)
{
    __disable_irq();
    
    ch0_data.captured = 0;
    ch1_data.captured = 0;
    ch0_data.capture_value = 0;
    ch1_data.capture_value = 0;
    global_overflow_count = 0;
    phase_measurement_ready = 0;
    
    gCH0_Captured = false;
    gCH1_Captured = false;
    gTimer_Overflow = false;
    
    __enable_irq();
}

/**
 * @brief 处理相位测量
 */
void MeasureDiff_Process(void)
{
    if (!phase_measurement_ready)
        return;
    
    // 禁用中断以确保数据一致性
    __disable_irq();
    
    // 保存当前数据
    uint32_t ch0_val = ch0_data.capture_value;
    uint32_t ch1_val = ch1_data.capture_value;
    uint32_t ch0_periods = ch0_data.overflow_count;
    uint32_t ch1_periods = ch1_data.overflow_count;
    
    __enable_irq();
    
    // 计算总的捕获时间（考虑各自的溢出次数）
    uint64_t total_ch0_time = (uint64_t)ch0_periods * (MAX_TIMER_VALUE + 1) + ch0_val;
    uint64_t total_ch1_time = (uint64_t)ch1_periods * (MAX_TIMER_VALUE + 1) + ch1_val;
    
    // 计算有符号时间差
    int64_t time_diff_signed = (int64_t)total_ch1_time - (int64_t)total_ch0_time;
    
    // 转换为实际时间（微秒）
    float time_diff_us = (float)time_diff_signed * 1000000.0f / TIMER_FREQ_HZ;
    
    // 使用固定的10kHz频率计算相位差
    float signal_period_us = Get_Signal_Period_Us();
    float phase_diff_temp = (time_diff_us / signal_period_us) * 360.0f;
    
    // 映射到 [-180, +180) 度范围
    while (phase_diff_temp > 180.0f)
        phase_diff_temp -= 360.0f;
    while (phase_diff_temp <= -180.0f)
        phase_diff_temp += 360.0f;
    
    // 获取当前均值和标准差
    float current_mean = Calculate_Average_Phase();
    float current_std = sqrtf(phase_variance);
    
    // 异常值检测
    uint8_t is_outlier = 0;
    if (valid_samples > 5) {  // 至少有5个样本才进行异常值检测
        is_outlier = Is_Phase_Outlier(phase_diff_temp, current_mean, current_std);
    }
    
    if (is_outlier) {
        outlier_count++;
        // 如果是异常值，使用上次有效值或当前均值
        if (valid_samples > 0) {
            phase_diff_temp = last_valid_phase;
        }
    } else {
        last_valid_phase = phase_diff_temp;
        valid_samples++;
    }
    
    // 将结果存入缓冲区
    phase_buffer[phase_buffer_index] = phase_diff_temp;
    phase_buffer_index++;
    
    if (phase_buffer_index >= PHASE_BUFFER_SIZE) {
        phase_buffer_index = 0;
        phase_buffer_full = 1;
    }
    
    // 计算滤波后的相位差
    float new_average = Calculate_Weighted_Average_Phase();
    
    // 应用移动平均滤波进一步平滑
    if (valid_samples == 1) {
        phase_difference_filtered = new_average;
    } else {
        phase_difference_filtered = Apply_Moving_Average_Filter(new_average, phase_difference_filtered);
    }
    
    phase_difference_deg = phase_difference_filtered;
    
    // 计算方差和标准差
    phase_variance = Calculate_Phase_Variance(phase_difference_deg);
    phase_std_dev = sqrtf(phase_variance);
    
    // 重置测量状态，准备下一次测量
    MeasureDiff_Reset();
}

/**
 * @brief 获取相位测量结果
 */
void MeasureDiff_GetResult(phase_measurement_result_t *result)
{
    if (result == NULL) return;
    
    result->phase_difference_deg = phase_difference_deg;
    result->phase_difference_filtered = phase_difference_filtered;
    result->signal_frequency = SIGNAL_FREQUENCY;  // 固定10kHz
    result->phase_std_dev = phase_std_dev;
    result->valid_samples = valid_samples;
    result->outlier_count = outlier_count;
    result->measurement_ready = phase_measurement_ready;
    result->system_stable = (phase_buffer_full && phase_std_dev < PHASE_STABILITY_THRESHOLD) ? 1 : 0;
}

/**
 * @brief 获取当前相位差（度）
 */
float MeasureDiff_GetPhaseDeg(void)
{
    return phase_difference_deg;
}

/**
 * @brief 获取当前频率（固定10kHz）
 */
float MeasureDiff_GetFrequency(void)
{
    return SIGNAL_FREQUENCY;
}

/**
 * @brief 获取测量稳定性状态
 */
uint8_t MeasureDiff_IsStable(void)
{
    return (phase_buffer_full && phase_std_dev < PHASE_STABILITY_THRESHOLD) ? 1 : 0;
}

/**
 * @brief 获取相位标准差
 */
float MeasureDiff_GetStdDev(void)
{
    return phase_std_dev;
}

/* 私有函数实现 */

/**
 * @brief 处理CH0捕获事件
 */
static void Process_CH0_Capture(void)
{
    uint32_t current_capture = DL_TimerA_getCaptureCompareValue(
        CAPTURE_0_INST, DL_TIMER_CC_0_INDEX);
    
    ch0_data.capture_value = current_capture;
    ch0_data.overflow_count = global_overflow_count;
    ch0_data.captured = 1;
    
    // 检查是否两个通道都已捕获
    if (ch0_data.captured && ch1_data.captured) {
        phase_measurement_ready = 1;
    }
}

/**
 * @brief 处理CH1捕获事件
 */
static void Process_CH1_Capture(void)
{
    uint32_t current_capture = DL_TimerA_getCaptureCompareValue(
        CAPTURE_0_INST, DL_TIMER_CC_1_INDEX);
    
    ch1_data.capture_value = current_capture;
    ch1_data.overflow_count = global_overflow_count;
    ch1_data.captured = 1;
    
    // 检查是否两个通道都已捕获
    if (ch0_data.captured && ch1_data.captured) {
        phase_measurement_ready = 1;
    }
}

/**
 * @brief 处理定时器溢出事件
 */
static void Process_Timer_Overflow(void)
{
    global_overflow_count++;
    
    // 防止溢出计数过大导致计算错误
    if (global_overflow_count > MAX_OVERFLOW_COUNT) {
        MeasureDiff_Reset();
        UART_send_string("Timer overflow reset\r\n");
    }
}

/**
 * @brief 获取信号周期（微秒） - 固定10kHz
 */
static float Get_Signal_Period_Us(void)
{
    return 1000000.0f / SIGNAL_FREQUENCY;  // 100微秒 for 10kHz
}

/**
 * @brief 应用移动平均滤波
 */
static float Apply_Moving_Average_Filter(float new_value, float old_value)
{
    return MOVING_AVG_ALPHA * new_value + (1.0f - MOVING_AVG_ALPHA) * old_value;
}

/**
 * @brief 检查相位值是否为异常值
 */
static uint8_t Is_Phase_Outlier(float phase_value, float mean, float std_dev)
{
    if (std_dev < 0.1f) return 0;  // 标准差太小，认为都是正常值
    
    // 计算角度差异（考虑循环性）
    float diff = fabsf(phase_value - mean);
    if (diff > 180.0f) diff = 360.0f - diff;
    
    // 使用3σ准则或固定阈值
    float threshold = fmaxf(3.0f * std_dev, OUTLIER_THRESHOLD);
    
    return (diff > threshold) ? 1 : 0;
}

/**
 * @brief 计算加权平均相位差
 */
static float Calculate_Weighted_Average_Phase(void)
{
    uint8_t count = phase_buffer_full ? PHASE_BUFFER_SIZE : phase_buffer_index;
    
    if (count == 0)
        return 0.0f;
    
    // 使用复数平均法处理角度循环问题，并应用权重
    float sum_cos = 0.0f;
    float sum_sin = 0.0f;
    float total_weight = 0.0f;
    
    for (uint8_t i = 0; i < count; i++) {
        float angle_rad = phase_buffer[i] * 3.141592653f / 180.0f;
        
        // 新数据权重更大
        float weight = 1.0f + (float)i / (float)count;
        
        sum_cos += cosf(angle_rad) * weight;
        sum_sin += sinf(angle_rad) * weight;
        total_weight += weight;
    }
    
    sum_cos /= total_weight;
    sum_sin /= total_weight;
    
    return atan2f(sum_sin, sum_cos) * 180.0f / 3.141592653f;
}

/**
 * @brief 计算平均相位差
 */
static float Calculate_Average_Phase(void)
{
    uint8_t count = phase_buffer_full ? PHASE_BUFFER_SIZE : phase_buffer_index;
    
    if (count == 0)
        return 0.0f;
    
    // 使用复数平均法处理角度循环问题
    float sum_cos = 0.0f;
    float sum_sin = 0.0f;
    
    for (uint8_t i = 0; i < count; i++) {
        float angle_rad = phase_buffer[i] * 3.141592653f / 180.0f;
        sum_cos += cosf(angle_rad);
        sum_sin += sinf(angle_rad);
    }
    
    sum_cos /= count;
    sum_sin /= count;
    
    return atan2f(sum_sin, sum_cos) * 180.0f / 3.141592653f;
}

/**
 * @brief 计算相位方差
 */
static float Calculate_Phase_Variance(float mean)
{
    uint8_t count = phase_buffer_full ? PHASE_BUFFER_SIZE : phase_buffer_index;
    
    if (count <= 1)
        return 0.0f;
    
    float sum_squared_diff = 0.0f;
    
    for (uint8_t i = 0; i < count; i++) {
        float diff = phase_buffer[i] - mean;
        
        // 处理角度循环性
        if (diff > 180.0f) diff -= 360.0f;
        if (diff < -180.0f) diff += 360.0f;
        
        sum_squared_diff += diff * diff;
    }
    
    return sum_squared_diff / (count - 1);
}

/* ADC和基础功能实现 */

void prepare_time_domain_data(uint16_t* adc_samples, float* output, uint16_t offset)
{
    for (uint16_t i = 0; i < TIME_DOMAIN_SAMPLES; i++) {
        output[i] = (float)(adc_samples[i + offset]) * ADC_VREF / ADC_RESOLUTION;
    }
}

void perform_time_domain_analysis(void)
{
    prepare_time_domain_data(gADC0Samples, gTimeDomainSignal0, 0);
    prepare_time_domain_data(gADC1Samples, gTimeDomainSignal1, 0);
    
    gDCOffset0 = calculate_dc_offset(gADC0Samples, 0, TIME_DOMAIN_SAMPLES) * ADC_VREF / ADC_RESOLUTION;
    gDCOffset1 = calculate_dc_offset(gADC1Samples, 0, TIME_DOMAIN_SAMPLES) * ADC_VREF / ADC_RESOLUTION;
    
    gAmplitude0 = calculate_amplitude(gTimeDomainSignal0, TIME_DOMAIN_SAMPLES);
    gAmplitude1 = calculate_amplitude(gTimeDomainSignal1, TIME_DOMAIN_SAMPLES);
    
    gPeakToPeak0 = calculate_peak_to_peak(gTimeDomainSignal0, TIME_DOMAIN_SAMPLES);
    gPeakToPeak1 = calculate_peak_to_peak(gTimeDomainSignal1, TIME_DOMAIN_SAMPLES);
}

float calculate_dc_offset(uint16_t* samples, uint16_t start, uint16_t count)
{
    uint32_t sum = 0;
    for (uint16_t i = start; i < start + count; i++) {
        sum += samples[i];
    }
    return (float)sum / count;
}

float calculate_amplitude(float* signal, uint16_t size)
{
    float max_val = signal[0];
    float min_val = signal[0];
    
    for (uint16_t i = 1; i < size; i++) {
        if (signal[i] > max_val) max_val = signal[i];
        if (signal[i] < min_val) min_val = signal[i];
    }
    
    return (max_val - min_val) / 2.0f;
}

float calculate_peak_to_peak(float* signal, uint16_t size)
{
    float max_val = signal[0];
    float min_val = signal[0];
    
    for (uint16_t i = 1; i < size; i++) {
        if (signal[i] > max_val) max_val = signal[i];
        if (signal[i] < min_val) min_val = signal[i];
    }
    
    return max_val - min_val;
}

void configure_timer_capture(void)
{
    // 启用定时器中断
    NVIC_EnableIRQ(CAPTURE_0_INST_INT_IRQN);
    NVIC_SetPriority(CAPTURE_0_INST_INT_IRQN, 2);

    // 清除定时器中断标志
    DL_TimerA_clearInterruptStatus(CAPTURE_0_INST, 
        DL_TIMERA_INTERRUPT_CC0_DN_EVENT | 
        DL_TIMERA_INTERRUPT_CC1_DN_EVENT |
        DL_TIMERA_INTERRUPT_ZERO_EVENT);

    // 启动定时器
    DL_TimerA_startCounter(CAPTURE_0_INST);
}

void output_results(void)
{
    phase_measurement_result_t result;
    MeasureDiff_GetResult(&result);
    
    // ADC时域分析结果
    sprintf(uart_buffer, "[ADC0] DC:%.3fV, Amp:%.3fV, P-P:%.3fV\r\n", 
            gDCOffset0, gAmplitude0, gPeakToPeak0);
    UART_send_string(uart_buffer);
    
    sprintf(uart_buffer, "[ADC1] DC:%.3fV, Amp:%.3fV, P-P:%.3fV\r\n", 
            gDCOffset1, gAmplitude1, gPeakToPeak1);
    UART_send_string(uart_buffer);
    
    // 高级相位测量结果
    sprintf(uart_buffer, "[Phase] Raw:%.2frad, Filtered:%.2frad, Freq:%.1fHz(Fixed)\r\n", 
            result.phase_difference_deg + 20, result.phase_difference_filtered + 20, result.signal_frequency);
    UART_send_string(uart_buffer);
    
    sprintf(uart_buffer, "[Stats] StdDev:%.2frad, Valid:%lu, Outliers:%lu, Stable:%s\r\n", 
            result.phase_std_dev, result.valid_samples, result.outlier_count,
            result.system_stable ? "YES" : "NO");
    UART_send_string(uart_buffer);
    
    UART_send_string("================================================\r\n");
}

void configure_adc_dma(void)
{
    gCheckADC0 = false;
    gCheckADC1 = false;
    
    DL_ADC12_setDMASamplesCnt(ADC12_0_INST, ADC_SAMPLE_SIZE);
    DL_ADC12_setDMASamplesCnt(ADC12_1_INST, ADC_SAMPLE_SIZE);
    
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_0_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);

    DL_DMA_setSrcAddr(DMA, DMA_CH1_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_1_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);

    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    NVIC_EnableIRQ(ADC12_1_INST_INT_IRQN);
    NVIC_SetPriority(ADC12_0_INST_INT_IRQN, 1);
    NVIC_SetPriority(ADC12_1_INST_INT_IRQN, 1);
    
    DL_ADC12_clearInterruptStatus(ADC12_0_INST, DL_ADC12_INTERRUPT_DMA_DONE);
    DL_ADC12_clearInterruptStatus(ADC12_1_INST, DL_ADC12_INTERRUPT_DMA_DONE);

    DL_ADC12_startConversion(ADC12_0_INST);
    DL_ADC12_startConversion(ADC12_1_INST);
}

/* 中断处理函数 */
void ADC12_0_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_0_INST);
    if (interruptStatus == DL_ADC12_IIDX_DMA_DONE) {
        gCheckADC0 = true;
    }
}

void ADC12_1_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_1_INST);
    if (interruptStatus == DL_ADC12_IIDX_DMA_DONE) {
        gCheckADC1 = true;
    }
}

void CAPTURE_0_INST_IRQHandler(void)
{
    switch (DL_TimerA_getPendingInterrupt(CAPTURE_0_INST)) {
        case DL_TIMERA_IIDX_CC0_DN:
            gCH0_Captured = true;
            break;

        case DL_TIMERA_IIDX_CC1_DN:
            gCH1_Captured = true;
            break;

        case DL_TIMERA_IIDX_ZERO:
            gTimer_Overflow = true;
            break;

        default:
            break;
    }
}

void UART_send_string(const char* str)
{
    while (*str) {
        while (DL_UART_Main_isBusy(UART_0_INST));
        DL_UART_Main_transmitData(UART_0_INST, *str++);
    }
}