/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
#include "LCDAPI.h"
#include "XJTU.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define XJTU_BLUE 0x02b3
#define Pi 3.14159265
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t dataL[240] = {
    3,11,8,5,3,2,1,0,0,2,4,8,17,39,43,17,11,9,8,7,7,7,8,9,12,19,89,26,3,5,6,6,
    7,9,11,13,18,26,47,136,154,40,21,14,11,9,8,7,8,8,11,16,36,36,12,8,6,4,4,3,
    3,2,2,2,1,4,32,4,0,0,1,1,1,2,2,3,4,6,10,22,12,7,4,2,1,1,0,0,0,1,2,5,12,9,
    6,4,3,3,3,2,2,2,2,2,3,4,3,3,2,2,1,1,1,1,1,2,2,3,5,7,4,2,1,1,1,1,1,2,2,3,4,
    6,7,6,4,2,2,1,1,0,0,0,0,0,1,2,2,1,1,1,1,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,1,1,1,0,0,0,0,1,1,1,2,3,3,3,2,2,2,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,
    0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0
};

uint8_t dataR[240] = {
    2,11,8,5,3,1,1,1,2,3,5,9,19,69,57,23,15,11,10,9,8,8,9,10,13,23,124,35,19,
    12,9,8,8,8,9,11,13,18,29,82,114,25,15,10,8,7,6,5,5,6,7,12,35,72,6,2,2,1,1,
    1,1,0,1,1,4,12,44,5,1,1,2,2,3,3,4,4,6,8,13,40,18,9,5,2,1,1,1,1,2,3,5,9,23,
    17,10,6,5,4,3,3,3,3,3,4,5,8,3,3,2,2,1,1,1,1,1,0,0,0,1,2,0,0,1,1,1,1,1,1,1,
    1,2,2,3,1,0,0,0,0,0,1,1,1,1,2,2,2,2,1,0,0,0,0,1,1,1,1,2,3,3,3,1,0,0,0,0,0,
    1,1,1,2,3,3,3,2,1,1,1,1,1,1,1,2,2,3,4,4,4,3,2,2,1,1,1,0,0,1,1,2,2,2,2,2,2,
    1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1
};
uint8_t dispflag = 1;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
void Display_Script(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI2_Init();
  MX_ADC1_Init();
  MX_DAC_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  LCD_Init();
  HAL_GPIO_WritePin(LED_R_GPIO_Port,LED_R_Pin,GPIO_PIN_RESET);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
		if(dispflag)
    {
      HAL_GPIO_WritePin(LED_G_GPIO_Port,LED_G_Pin,GPIO_PIN_SET);
      HAL_Delay(200);
      HAL_GPIO_WritePin(LED_G_GPIO_Port,LED_G_Pin,GPIO_PIN_RESET);
      Display_Script();
      HAL_GPIO_WritePin(LED_G_GPIO_Port,LED_G_Pin,GPIO_PIN_SET);
      HAL_Delay(200);
      HAL_GPIO_WritePin(LED_G_GPIO_Port,LED_G_Pin,GPIO_PIN_RESET);
      dispflag = 0;
    }
    /* USER CODE BEGIN 3 */
  
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 12;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if(GPIO_Pin == KEY_Pin)
  {
    dispflag = 1;
  }
}
void Display_Script()
{
  /* Start */
  
  
  
  /* Screen 1 */
  LCD_FillScreen(WHITE);
  LCD_Disp_Text(15,40,BLACK,2,ASCII5x5,"PDP");
	HAL_Delay(3000);
  LCD_Disp_Text(49,60,BLACK,2,ASCII5x5,"by HSSE@Xjtu");
  LCD_Disp_Text(49,80,BLACK,2,ASCII5x5,"Version");
  LCD_Disp_Decimal(145,80,BLACK,2,ASCII5x5,1.12,1,2);
  LCD_Disp_Text(97,100,BLACK,2,ASCII5x7,"Demo");
  LCD_Disp_Text(1,140,BLACK,1,ASCII16,"ILI9341 Mode: 4-Line 8-Bit SPI");
  LCD_Disp_Text(25,160,BLACK,1,ASCII16,"SPI Speed: 12.5Mbit/s");
  LCD_Disp_Text(25,180,BLACK,1,ASCII16,"Heap Size: 0x200");
  LCD_Disp_Text(41,300,BLACK,2,ASCII5x5,"pi = 3.");
  LCD_Disp_Num(125,300,BLACK,2,ASCII5x5,14159265,7,LCD_NUM_UPPERDIGITS);
  HAL_Delay(3000);
  
  /* Screen 2 */
  LCD_FillScreen(WHITE);
  LCD_Disp_Text(56,12,BLACK,1,ASCII16," !\"#$%&\'()*+,-./");
  LCD_Disp_Text(56,28,BLACK,1,ASCII16,"0123456789:;<=>?");
  LCD_Disp_Text(56,44,BLACK,1,ASCII16,"@ABCDEFGHIJKLMNO");
  LCD_Disp_Text(56,60,BLACK,1,ASCII16,"PQRSTUVWXYZ[\\]^_");
  LCD_Disp_Text(56,76,BLACK,1,ASCII16,"`abcdefghijklmno");
  LCD_Disp_Text(56,92,BLACK,1,ASCII16,"pqrstuvwxyz{|}~ ");
  
  LCD_Disp_Text(25,132,BLACK,2,ASCII5x5," !\"#$%&\'()*+,-./");
  LCD_Disp_Text(25,144,BLACK,2,ASCII5x5,"0123456789:;<=>?");
  LCD_Disp_Text(25,156,BLACK,2,ASCII5x5,"@ABCDEFGHIJKLMNO");
  LCD_Disp_Text(25,168,BLACK,2,ASCII5x5,"PQRSTUVWXYZ[\\]^_");
  LCD_Disp_Text(25,180,BLACK,2,ASCII5x5,"`abcdefghijklmno");
  LCD_Disp_Text(25,192,BLACK,2,ASCII5x5,"pqrstuvwxyz{|}~ ");
  
  LCD_Disp_Text(25,216,BLACK,2,ASCII5x7," !\"#$%&\'()*+,-./");
  LCD_Disp_Text(25,232,BLACK,2,ASCII5x7,"0123456789:;<=>?");
  LCD_Disp_Text(25,248,BLACK,2,ASCII5x7,"@ABCDEFGHIJKLMNO");
  LCD_Disp_Text(25,264,BLACK,2,ASCII5x7,"PQRSTUVWXYZ[\\]^_");
  LCD_Disp_Text(25,280,BLACK,2,ASCII5x7,"`abcdefghijklmno");
  LCD_Disp_Text(25,296,BLACK,2,ASCII5x7,"pqrstuvwxyz{|}~ ");
  HAL_Delay(5000);
  
  /* Screen 3 */
  LCD_FillScreen(GRAY3);
  LCD_Draw_Box_Filled(237,3,2,158,WHITE);
  LCD_Draw_Box_Filled(237,163,2,318,WHITE);
  LCD_Disp_Axis_Quadrant(2,158,238,158,3,BLACK);
  LCD_Disp_Axis_Quadrant(2,318,238,158,3,BLACK);
  LCD_Draw_Line_Vertical(3,4,154,ARTI);
  LCD_Draw_Line_Vertical(3,164,154,SPEAR);
  for(uint16_t i = 3; i < 236; i++)
  {
    LCD_Draw_Line_Vertical(i+1,4,154,ARTI);
    LCD_Draw_Line_Vertical(i+1,164,154,SPEAR);
    LCD_Draw_Line_Vertical(i,4,154,WHITE);
    LCD_Draw_Line_Vertical(i,164,154,WHITE);
    LCD_Draw_Pixel(i,157-dataL[i],RED);
    LCD_Draw_Pixel(i,317-dataR[i],BLUE);
    LCD_Draw_Line_Vertical(i,158-dataL[i],dataL[i],HUNTER);
    LCD_Draw_Line_Vertical(i,318-dataR[i],dataR[i],RIVULET);
  }
  LCD_Draw_Line_Vertical(236,4,154,WHITE);
  LCD_Draw_Line_Vertical(236,164,154,WHITE);
  LCD_Draw_Pixel(236,157-dataL[236],RED);
  LCD_Draw_Pixel(236,317-dataR[236],BLUE);
  LCD_Draw_Line_Vertical(236,158-dataL[236],dataL[236],HUNTER);
  LCD_Draw_Line_Vertical(236,318-dataR[236],dataR[236],RIVULET);
  HAL_Delay(3000);
  LCD_Draw_Line_Horizontal(0,0,240,GREEN);
  for(uint16_t i = 0; i <= 320; i++)
  {
    LCD_Draw_Line_Horizontal(0,i+1,240,GREEN);
    LCD_Draw_Line_Horizontal(0,i,240,WHITE);
  }
  HAL_Delay(200);
  
  /* Screen 4 */
  LCD_FillScreen(ENOT);
  LCD_Draw_Pixel(120,160,WHITE);
  for(uint16_t i = 0; i < 60; i++)
  {
    LCD_Draw_Line(120 + 10*cos(2*Pi*i/60), 160 - 10*sin(2*Pi*i/60),
                  120 + 99*cos(2*Pi*i/60), 160 - 99*sin(2*Pi*i/60),
                  WHITE);
  }
  
  HAL_Delay(1500);
  LCD_Draw_Circle_Filled(120,160,100,WHITE);
  HAL_Delay(500);
  for(uint16_t i = 99; i > 0; i--)
  {
    LCD_Draw_Circle_Hollow(120,160,100-i,((i*32/100&0x1F)<<11)+((i*64/100&0x3F)<<5)+((i*32/100&0x1F)));
  }
  LCD_Draw_Circle_Hollow(120,160,100,0x0000);
  LCD_Draw_Circle_Hollow(120,160,40,BLUE);
  LCD_Draw_Circle_Hollow(120,160,60,GREEN);
  LCD_Draw_Circle_Hollow(120,160,80,RED);
  HAL_Delay(1900);
  LCD_Draw_Circle_Filled(120,160,100,WHITE);
  HAL_Delay(200);
  for(uint16_t i = 0; i < 100; i+=3)
  {
    LCD_Draw_Circle_Filled(120,160,100-i,((i*32/100&0x1F)<<11)+((i*64/100&0x3F)<<5)+((i*32/100&0x1F)));
  }
  HAL_Delay(1900);
  
  /* Screen 5 */
  LCD_FillScreen(WHITE);
  LCD_Disp_DotGrid(0,0,XJTU_LOGO,30,240,XJTU_BLUE);
  LCD_Disp_DotGrid(0,240,XJTU_Motto_Line1,30,16,BLACK);
  LCD_Disp_DotGrid(0,268,XJTU_Motto_Line2,30,16,BLACK);
  LCD_Disp_Text(24,300,BLACK,1,ASCII16,"Press K1 to Restart Demo");
  
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
