/**
 ******************************************************************************
 * @file           : audio_system_simulator.c
 * @brief          : ��Ƶϵͳ��Ϊģ���� - ѧϰģʽ�빤��ģʽ
 * @description    : ѧϰģʽ��AD9833ɨƵ����ϵͳ��Ƶ��Ӧ�������������ʶ���˲�������
 *                  ����ģʽ��ʵʱƵ�ʷ��������������ģ��ϵͳ��Ϊ���
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#define ARM_MATH_CM4
#include "main.h"
#include "tim.h"
#include "gpio.h"
#include "adc.h"
#include "dac.h"
#include "dma.h"
#include "spi.h"
#include "ad9833.h"
#include "LCDAPI.h"
#include "arm_math.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Private defines -----------------------------------------------------------*/
// ϵͳ����ģʽ
typedef enum
{
    MODE_LEARNING = 0, // ѧϰģʽ��ɨƵ���ԣ�
    MODE_WORKING = 1   // ����ģʽ��ϵͳ��Ϊģ�⣩
} SystemMode_t;

// �˲�������ʶ��
typedef enum
{
    FILTER_UNKNOWN = 0,
    FILTER_LOWPASS,  // ��ͨ�˲���
    FILTER_HIGHPASS, // ��ͨ�˲���
    FILTER_BANDPASS, // ��ͨ�˲���
    FILTER_BANDSTOP, // �����˲���
    FILTER_ALLPASS   // ȫͨ�˲���
} FilterType_t;

// ADC/DAC����������
#define BUFFER_SIZE 2048
#define FFT_SIZE 4096
#define SAMPLE_RATE 500000
#define FREQ_RESOLUTION (SAMPLE_RATE / FFT_SIZE)

// ѧϰģʽɨƵ����
#define LEARN_MIN_FREQ 200       // ѧϰ��СƵ�� 200Hz
#define LEARN_MAX_FREQ 50000     // ѧϰ���Ƶ�� 50kHz
#define LEARN_FREQ_STEP 200      // ѧϰƵ�ʲ��� 200Hz
#define LEARN_INTERVAL 100       // ѧϰ��� 100ms
#define LEARN_REFERENCE_VPP 3.0f // ѧϰģʽ�ο���ѹ 3V���ֵ

// ���������
#define MAX_GAIN_ENTRIES 250 // ����������Ŀ��
#define GAIN_SMOOTH_FACTOR 0.05f
#define GAIN_UPDATE_SAMPLES 100

// ��ͼ��ض���
#define PLOT_X_START 20 // ��ͼ����X��ʼλ��
#define PLOT_Y_START 80 // ��ͼ����Y��ʼλ��
#define PLOT_WIDTH 200  // ��ͼ�������
#define PLOT_HEIGHT 120 // ��ͼ����߶�

// LCD��ɫ���� - ����Ϊ��ɫ��������
#define COLOR_WHITE 0xFFFF
#define COLOR_BLACK 0x0000
#define COLOR_RED 0xF800
#define COLOR_GREEN 0x07E0
#define COLOR_BLUE 0x001F
#define COLOR_YELLOW 0xFFE0
#define COLOR_CYAN 0x07FF
#define COLOR_MAGENTA 0xF81F
#define COLOR_ORANGE 0xFD20
#define COLOR_GRAY 0x8410
#define COLOR_DARK_BLUE 0x0010    // ����ɫ���ڰױ����Ͽɼ�
#define COLOR_DARK_GREEN 0x03E0   // ����ɫ���ڰױ����Ͽɼ�
#define COLOR_PURPLE 0x8010       // ��ɫ���ڰױ����Ͽɼ�

/* Private typedef -----------------------------------------------------------*/
// �������Ŀ�ṹ��
typedef struct
{
    uint32_t frequency;     // Ƶ�� (Hz)
    float32_t system_gain;  // ϵͳʵ�����棨����ֵ/�ο�ֵ��
    float32_t peak_to_peak; // ���ֵ (V)
    float32_t rms_value;    // RMSֵ (V)
    uint8_t valid;          // ������Ч��
} GainTableEntry_t;

/* Private variables ---------------------------------------------------------*/
// ϵͳ״̬
static SystemMode_t current_mode = MODE_LEARNING;
static uint8_t mode_switch_flag = 0;

// ADC/DAC������
static uint16_t adc_input_buffer[BUFFER_SIZE];
static uint16_t dac_output_buffer[BUFFER_SIZE];

// FFT��أ�����ģʽʹ�ã�
static float32_t fft_input_buffer[FFT_SIZE * 2];
static float32_t fft_output_buffer[FFT_SIZE];
static arm_rfft_fast_instance_f32 fft_instance;
static uint16_t fft_data_buffer[FFT_SIZE];
static volatile uint16_t fft_buffer_index = 0;
static volatile uint8_t fft_data_ready = 0;

// ѧϰģʽ����
static uint32_t learn_current_freq = LEARN_MIN_FREQ;
static uint8_t learning_active = 0;
static uint32_t last_learn_time = 0;
static uint16_t learn_progress = 0;
static uint16_t total_learn_points = 0;

// ��������˲���ʶ��
static GainTableEntry_t gain_table[MAX_GAIN_ENTRIES];
static uint16_t gain_table_size = 0;
static uint8_t gain_table_ready = 0;
static FilterType_t identified_filter_type = FILTER_UNKNOWN;
static char filter_type_name[20] = "Unknown";
static float32_t cutoff_frequency = 0;
static float32_t max_gain_freq = 0;
static float32_t max_gain_value = 0;

// ����ģʽ����
static float32_t dominant_frequency = 0;
static float32_t dominant_amplitude = 0;
static volatile float32_t current_simulation_gain = 1.0f;
static volatile float32_t target_simulation_gain = 1.0f;
static volatile uint32_t gain_update_counter = 0;

// ��������
static float32_t current_peak_to_peak = 0.0f;
static float32_t current_rms = 0.0f;
static uint32_t processed_samples = 0;
static uint8_t plot_updated = 0;

// ��ʾ���
static char display_string[60];
static uint32_t last_display_time = 0;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

// ѧϰģʽ����
void Learning_Mode_Init(void);
void Learning_Mode_Process(void);
void Learning_Mode_Set_Frequency(uint32_t frequency);
uint32_t Learning_Mode_Get_Next_Frequency(void);
void Learning_Mode_Measure_Response(void);
void Learning_Mode_Analyze_Filter_Type(void);

// ����ģʽ����
void Working_Mode_Init(void);
void Working_Mode_Process(void);
void Working_Mode_Process_FFT(void);
void Working_Mode_Update_Simulation(void);
void Working_Mode_Process_Audio_Buffer(void);

// �������������
float32_t Get_System_Gain_For_Frequency(float32_t frequency);
void Add_Gain_Table_Entry(uint32_t freq, float32_t system_gain, float32_t pp, float32_t rms);

// �˲�������ʶ����
void Identify_Filter_Type(void);
float32_t Find_Cutoff_Frequency(float32_t target_gain_ratio);

// ��������
void Calculate_Peak_To_Peak_RMS(uint16_t *buffer, uint16_t size, float32_t *pp, float32_t *rms);

// ϵͳ���ƺ���
void Switch_System_Mode(SystemMode_t new_mode);
void Handle_User_Input(void);

// ��ͼ����
void Clear_Plot_Area(void);
void Draw_Plot_Axes(void);
void Plot_Frequency_Response(void);

// ��ʾ����
void Display_System_Status(void);
void Learning_Mode_Display(void);
void Working_Mode_Display(void);

// �ص�����
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc);
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc);

/* Private user code ---------------------------------------------------------*/

/**
 * @brief  ������
 */
int main(void)
{
    /* MCU Configuration */
    HAL_Init();
    SystemClock_Config();

    /* Initialize peripherals */
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_ADC1_Init();
    MX_DAC_Init();
    MX_TIM2_Init();
    MX_TIM3_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();

    /* Initialize LCD */
    LCD_Init();
    LCD_FillScreen(COLOR_WHITE);  // ��ɫ����
    LCD_Disp_Text(5, 5, COLOR_BLACK, 2, ASCII5x7, "Audio System Simulator");
    LCD_Disp_Text(10, 30, COLOR_BLUE, 1, ASCII5x7, "Initializing...");
    HAL_Delay(1000);

    /* Initialize FFT */
    arm_rfft_fast_init_f32(&fft_instance, FFT_SIZE);

    /* Initialize AD9833 */
    AD9833_GPIOinit();

    /* Calculate total learning points */
    total_learn_points = (LEARN_MAX_FREQ - LEARN_MIN_FREQ) / LEARN_FREQ_STEP + 1;

    /* Start in learning mode */
    Learning_Mode_Init();

    /* Initialize DAC output buffer */
    for (int i = 0; i < BUFFER_SIZE; i++)
    {
        dac_output_buffer[i] = 2048; // 12-bit�е�ֵ
    }

    /* Start timers */
    HAL_TIM_Base_Start(&htim3); // ADC trigger
    HAL_TIM_Base_Start(&htim2); // DAC trigger

    /* Start ADC DMA */
    HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_input_buffer, BUFFER_SIZE);
    HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1, (uint32_t *)dac_output_buffer, BUFFER_SIZE, DAC_ALIGN_12B_R);

    /* Start peripherals */
    HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
    HAL_ADC_Start(&hadc1);

    HAL_Delay(500);

    /* Main loop */
    while (1)
    {
        // �����û�����
        Handle_User_Input();

        // ģʽ�л�����
        if (mode_switch_flag)
        {
            mode_switch_flag = 0;
            if (current_mode == MODE_LEARNING)
            {
                Switch_System_Mode(MODE_WORKING);
            }
            else
            {
                Switch_System_Mode(MODE_LEARNING);
            }
        }

        // ģʽ����
        if (current_mode == MODE_LEARNING)
        {
            Learning_Mode_Process();
        }
        else
        {
            Working_Mode_Process();
        }

        // ������ʾ
        if (HAL_GetTick() - last_display_time > 200)
        {
            Display_System_Status();
            last_display_time = HAL_GetTick();
        }

        HAL_Delay(10);
    }
}

/**
 * @brief  ѧϰģʽ��ʼ��
 */
void Learning_Mode_Init(void)
{
    current_mode = MODE_LEARNING;
    learning_active = 0;
    learn_current_freq = LEARN_MIN_FREQ;
    learn_progress = 0;
    gain_table_size = 0;
    gain_table_ready = 0;
    identified_filter_type = FILTER_UNKNOWN;
    strcpy(filter_type_name, "Unknown");

    // ��ȫ������ȷ��û�в�����ʾ
    LCD_FillScreen(COLOR_WHITE);

    // ����������
    Draw_Plot_Axes();

    LCD_Disp_Text(5, 5, COLOR_BLACK, 2, ASCII5x7, "LEARNING MODE");
    LCD_Disp_Text(10, 30, COLOR_DARK_BLUE, 1, ASCII5x7, "Press PD12 to start learning");
    LCD_Disp_Text(10, 45, COLOR_BLUE, 1, ASCII5x7, "Range: 200Hz - 50kHz, Step: 200Hz");

    // ���ó�ʼƵ��
    Learning_Mode_Set_Frequency(learn_current_freq);
}

/**
 * @brief  ѧϰģʽ����
 */
void Learning_Mode_Process(void)
{
    if (!learning_active)
        return;

    // ����Ƿ����л�Ƶ�ʵ�ʱ��
    if (HAL_GetTick() - last_learn_time >= LEARN_INTERVAL)
    {

        // ������ǰƵ�ʵ�ϵͳ��Ӧ
        Learning_Mode_Measure_Response();

        // �л�����һ��Ƶ��
        uint32_t next_freq = Learning_Mode_Get_Next_Frequency();
        if (next_freq == LEARN_MIN_FREQ)
        {
            // ѧϰ���
            learning_active = 0;
            Learning_Mode_Analyze_Filter_Type();
            gain_table_ready = 1;
        }
        else
        {
            Learning_Mode_Set_Frequency(next_freq);
            learn_progress++;
        }

        last_learn_time = HAL_GetTick();
    }

    // ����Ƶ����Ӧ����
    Plot_Frequency_Response();
}

/**
 * @brief  ����ѧϰģʽƵ��
 */
void Learning_Mode_Set_Frequency(uint32_t frequency)
{
    if (frequency < LEARN_MIN_FREQ)
        frequency = LEARN_MIN_FREQ;
    if (frequency > LEARN_MAX_FREQ)
        frequency = LEARN_MAX_FREQ;

    learn_current_freq = frequency;
    AD9833_FreqSet((double)frequency);
    AD9833_CtrlSet(0, 0, 0, 0); // ���Ҳ����
}

/**
 * @brief  ��ȡ��һ��ѧϰƵ��
 */
uint32_t Learning_Mode_Get_Next_Frequency(void)
{
    uint32_t next_freq = learn_current_freq + LEARN_FREQ_STEP;
    if (next_freq > LEARN_MAX_FREQ)
    {
        return LEARN_MIN_FREQ; // ѧϰ��ɱ�־
    }
    return next_freq;
}

/**
 * @brief  ����ϵͳ��Ӧ
 */
void Learning_Mode_Measure_Response(void)
{
    // �ȴ��ź��ȶ�
    HAL_Delay(50);

    // ���㵱ǰƵ�ʵĲ���ֵ
    Calculate_Peak_To_Peak_RMS(adc_input_buffer, BUFFER_SIZE, &current_peak_to_peak, &current_rms);

    // ����ϵͳ���棨ʵ�ʲ���ֵ/�ο�ֵ��
    float32_t system_gain = current_peak_to_peak / LEARN_REFERENCE_VPP;

    // ���ӵ������
    Add_Gain_Table_Entry(learn_current_freq, system_gain, current_peak_to_peak, current_rms);
    plot_updated = 1; // ��ǻ�ͼ��Ҫ����
}

/**
 * @brief  �����˲�������
 */
void Learning_Mode_Analyze_Filter_Type(void)
{
    Identify_Filter_Type();
}

/**
 * @brief  ʶ���˲�������
 */
void Identify_Filter_Type(void)
{
    if (gain_table_size < 10)
    {
        identified_filter_type = FILTER_UNKNOWN;
        strcpy(filter_type_name, "Unknown");
        return;
    }

    // �ҵ���������
    max_gain_value = 0;
    max_gain_freq = 0;
    for (uint16_t i = 0; i < gain_table_size; i++)
    {
        if (gain_table[i].valid && gain_table[i].system_gain > max_gain_value)
        {
            max_gain_value = gain_table[i].system_gain;
            max_gain_freq = gain_table[i].frequency;
        }
    }

    // �����Ƶ�͸�Ƶ��ƽ������
    float32_t low_freq_gain = 0, high_freq_gain = 0;
    uint16_t low_count = 0, high_count = 0;

    for (uint16_t i = 0; i < gain_table_size; i++)
    {
        if (!gain_table[i].valid)
            continue;

        if (gain_table[i].frequency < 2000)
        { // ��Ƶ�� < 2kHz
            low_freq_gain += gain_table[i].system_gain;
            low_count++;
        }
        else if (gain_table[i].frequency > 20000)
        { // ��Ƶ�� > 20kHz
            high_freq_gain += gain_table[i].system_gain;
            high_count++;
        }
    }

    if (low_count > 0)
        low_freq_gain /= low_count;
    if (high_count > 0)
        high_freq_gain /= high_count;

    // �ж��˲�������
    float32_t gain_ratio_threshold = 0.7f; // �������ֵ

    if (low_freq_gain > high_freq_gain * 2.0f)
    {
        // ��ͨ�˲�������Ƶ�������Ը��ڸ�Ƶ
        identified_filter_type = FILTER_LOWPASS;
        strcpy(filter_type_name, "Low Pass");
        cutoff_frequency = Find_Cutoff_Frequency(gain_ratio_threshold);
    }
    else if (high_freq_gain > low_freq_gain * 2.0f)
    {
        // ��ͨ�˲�������Ƶ�������Ը��ڵ�Ƶ
        identified_filter_type = FILTER_HIGHPASS;
        strcpy(filter_type_name, "High Pass");
        cutoff_frequency = Find_Cutoff_Frequency(gain_ratio_threshold);
    }
    else if (max_gain_freq > LEARN_MIN_FREQ + 1000 && max_gain_freq < LEARN_MAX_FREQ - 1000)
    {
        // ��ͨ������˲��������/��С�������м�Ƶ��
        float32_t mid_to_edge_ratio = max_gain_value / ((low_freq_gain + high_freq_gain) / 2.0f);

        if (mid_to_edge_ratio > 1.5f)
        {
            identified_filter_type = FILTER_BANDPASS;
            strcpy(filter_type_name, "Band Pass");
        }
        else if (mid_to_edge_ratio < 0.7f)
        {
            identified_filter_type = FILTER_BANDSTOP;
            strcpy(filter_type_name, "Band Stop");
        }
        else
        {
            identified_filter_type = FILTER_ALLPASS;
            strcpy(filter_type_name, "All Pass");
        }
        cutoff_frequency = max_gain_freq;
    }
    else
    {
        identified_filter_type = FILTER_ALLPASS;
        strcpy(filter_type_name, "All Pass");
        cutoff_frequency = 0;
    }
}

/**
 * @brief  ���ҽ�ֹƵ��
 */
float32_t Find_Cutoff_Frequency(float32_t target_gain_ratio)
{
    float32_t reference_gain = max_gain_value * target_gain_ratio; // -3dB��

    for (uint16_t i = 0; i < gain_table_size - 1; i++)
    {
        if (!gain_table[i].valid || !gain_table[i + 1].valid)
            continue;

        if ((gain_table[i].system_gain >= reference_gain && gain_table[i + 1].system_gain < reference_gain) ||
            (gain_table[i].system_gain <= reference_gain && gain_table[i + 1].system_gain > reference_gain))
        {
            return gain_table[i].frequency;
        }
    }

    return 0; // δ�ҵ���ֹƵ��
}

/**
 * @brief  ����ģʽ��ʼ��
 */
void Working_Mode_Init(void)
{
    current_mode = MODE_WORKING;
    fft_buffer_index = 0;
    fft_data_ready = 0;
    current_simulation_gain = 1.0f;
    target_simulation_gain = 1.0f;
    processed_samples = 0;

    // ��ȫ������ȷ��û�в�����ʾ
    LCD_FillScreen(COLOR_WHITE);
    
    LCD_Disp_Text(5, 5, COLOR_BLACK, 2, ASCII5x7, "WORKING MODE");
    LCD_Disp_Text(10, 30, COLOR_DARK_GREEN, 1, ASCII5x7, "System Behavior Simulation");

    if (gain_table_ready)
    {
        LCD_Disp_Text(10, 45, COLOR_BLUE, 1, ASCII5x7, "Gain Table Loaded");
        sprintf(display_string, "Filter: %s", filter_type_name);
        LCD_Disp_Text(10, 60, COLOR_PURPLE, 1, ASCII5x7, display_string);
    }
    else
    {
        LCD_Disp_Text(10, 45, COLOR_RED, 1, ASCII5x7, "No Gain Table - Learning Required");
    }
}

/**
 * @brief  ����ģʽ����
 */
void Working_Mode_Process(void)
{
    // ����FFT����
    if (fft_data_ready)
    {
        Working_Mode_Process_FFT();
        Working_Mode_Update_Simulation();
        fft_data_ready = 0;
    }
}

/**
 * @brief  ����ģʽFFT����
 */
void Working_Mode_Process_FFT(void)
{
    // ��ADC����ת��Ϊ��������׼��FFT����
    for (int i = 0; i < FFT_SIZE; i++)
    {
        fft_input_buffer[i] = (float32_t)(fft_data_buffer[i] - 2048);
    }

    // ִ��FFT
    arm_rfft_fast_f32(&fft_instance, fft_input_buffer, fft_input_buffer, 0);

    // ���������
    arm_cmplx_mag_f32(fft_input_buffer, fft_output_buffer, FFT_SIZE / 2);

    // �ҵ���ҪƵ�ʳɷ�
    dominant_amplitude = 0;
    uint16_t dominant_bin = 1;

    for (int i = 1; i < FFT_SIZE / 2; i++)
    {
        if (fft_output_buffer[i] > dominant_amplitude)
        {
            dominant_amplitude = fft_output_buffer[i];
            dominant_bin = i;
        }
    }

    dominant_frequency = (float32_t)dominant_bin * FREQ_RESOLUTION;
}

/**
 * @brief  ����ϵͳģ������
 */
void Working_Mode_Update_Simulation(void)
{
    if (gain_table_ready && dominant_frequency > 0 && dominant_amplitude > 50)
    {
        // ��ȡ��Ƶ�ʶ�Ӧ��ϵͳ���棬ֱ��ģ��ϵͳ��Ϊ
        target_simulation_gain = Get_System_Gain_For_Frequency(dominant_frequency);
    }
    else
    {
        target_simulation_gain = 1.0f; // Ĭ����˥��
    }
}

/**
 * @brief  ����ģʽ��Ƶ����������
 */
void Working_Mode_Process_Audio_Buffer(void)
{
    // ����������������ģ��ϵͳ��Ϊ
    for (int i = 0; i < BUFFER_SIZE; i++)
    {
        // ƽ������ģ������
        if (gain_update_counter++ >= GAIN_UPDATE_SAMPLES)
        {
            current_simulation_gain += (target_simulation_gain - current_simulation_gain) * GAIN_SMOOTH_FACTOR;
            gain_update_counter = 0;
        }

        // ��ADC��������ȡ�����ź�
        uint16_t input_sample = adc_input_buffer[i];

        // ת��Ϊ�з���ֵ���д���
        int32_t centered_input = (int32_t)input_sample - 2048;

        // Ӧ��ϵͳ���棨ģ��ϵͳ��Ϊ������ �� ϵͳ���棩
        int32_t simulated_output = (int32_t)(centered_input * current_simulation_gain);

        // ת�����޷���12λֵ
        int32_t output_sample = simulated_output + 2048;

        // ���������Χ
        if (output_sample < 0)
            output_sample = 0;
        if (output_sample > 4095)
            output_sample = 4095;

        // д��DAC���������
        dac_output_buffer[i] = (uint16_t)output_sample;

        processed_samples++;
    }
}

/**
 * @brief  ����Ƶ�ʻ�ȡϵͳ����
 */
float32_t Get_System_Gain_For_Frequency(float32_t frequency)
{
    if (!gain_table_ready || gain_table_size == 0)
    {
        return 1.0f;
    }

    // Ѱ����ӽ���Ƶ�ʵ�
    uint16_t closest_index = 0;
    float32_t min_diff = fabsf(frequency - gain_table[0].frequency);

    for (uint16_t i = 1; i < gain_table_size; i++)
    {
        if (gain_table[i].valid)
        {
            float32_t diff = fabsf(frequency - gain_table[i].frequency);
            if (diff < min_diff)
            {
                min_diff = diff;
                closest_index = i;
            }
        }
    }

    return gain_table[closest_index].system_gain;
}

/**
 * @brief  �����������Ŀ
 */
void Add_Gain_Table_Entry(uint32_t freq, float32_t system_gain, float32_t pp, float32_t rms)
{
    if (gain_table_size < MAX_GAIN_ENTRIES)
    {
        gain_table[gain_table_size].frequency = freq;
        gain_table[gain_table_size].system_gain = system_gain;
        gain_table[gain_table_size].peak_to_peak = pp;
        gain_table[gain_table_size].rms_value = rms;
        gain_table[gain_table_size].valid = 1;
        gain_table_size++;
    }
}

/**
 * @brief  ������ֵ��RMSֵ
 */
void Calculate_Peak_To_Peak_RMS(uint16_t *buffer, uint16_t size, float32_t *pp, float32_t *rms)
{
    uint32_t sum_squares = 0;
    uint16_t max_raw = 0;
    uint16_t min_raw = 4095;

    for (uint16_t i = 0; i < size; i++)
    {
        uint16_t value = buffer[i];
        sum_squares += value * value;
        if (value > max_raw)
            max_raw = value;
        if (value < min_raw)
            min_raw = value;
    }

    const float32_t voltage_ref = 3.3f;
    const float32_t adc_resolution = 4095.0f;

    *pp = ((max_raw - min_raw) / adc_resolution) * voltage_ref;

    float32_t mean_squares = sum_squares / (float32_t)size;
    *rms = sqrtf(mean_squares / (adc_resolution * adc_resolution)) * voltage_ref;
}

/**
 * @brief  �����ͼ����
 */
void Clear_Plot_Area(void)
{
    LCD_Draw_Box_Filled(PLOT_X_START, PLOT_Y_START,
                        PLOT_X_START + PLOT_WIDTH, PLOT_Y_START + PLOT_HEIGHT,
                        COLOR_WHITE);  // ��ɫ����
}

/**
 * @brief  ����������
 */
void Draw_Plot_Axes(void)
{
    // �����ͼ����
    Clear_Plot_Area();

    // ����X��
    LCD_Draw_Line(PLOT_X_START, PLOT_Y_START + PLOT_HEIGHT,
                  PLOT_X_START + PLOT_WIDTH, PLOT_Y_START + PLOT_HEIGHT, COLOR_BLACK);

    // ����Y��
    LCD_Draw_Line(PLOT_X_START, PLOT_Y_START,
                  PLOT_X_START, PLOT_Y_START + PLOT_HEIGHT, COLOR_BLACK);

    // ����������
    for (int i = 1; i < 5; i++)
    {
        // ��ֱ������
        uint16_t x = PLOT_X_START + (PLOT_WIDTH * i) / 5;
        LCD_Draw_Line(x, PLOT_Y_START, x, PLOT_Y_START + PLOT_HEIGHT, COLOR_GRAY);

        // ˮƽ������
        uint16_t y = PLOT_Y_START + (PLOT_HEIGHT * i) / 5;
        LCD_Draw_Line(PLOT_X_START, y, PLOT_X_START + PLOT_WIDTH, y, COLOR_GRAY);
    }

    // �������ǩ
    LCD_Disp_Text(PLOT_X_START - 15, PLOT_Y_START - 10, COLOR_BLACK, 1, ASCII5x7, "Gain");
    LCD_Disp_Text(PLOT_X_START + PLOT_WIDTH - 15, PLOT_Y_START + PLOT_HEIGHT + 5, COLOR_BLACK, 1, ASCII5x7, "f(kHz)");

    // Y��̶ȱ�ǩ (���棺0-2.0)
    LCD_Disp_Text(PLOT_X_START - 10, PLOT_Y_START, COLOR_BLACK, 1, ASCII5x7, "2.0");
    LCD_Disp_Text(PLOT_X_START - 10, PLOT_Y_START + PLOT_HEIGHT / 2, COLOR_BLACK, 1, ASCII5x7, "1.0");
    LCD_Disp_Text(PLOT_X_START - 10, PLOT_Y_START + PLOT_HEIGHT, COLOR_BLACK, 1, ASCII5x7, "0");

    // X��̶ȱ�ǩ
    LCD_Disp_Text(PLOT_X_START, PLOT_Y_START + PLOT_HEIGHT + 5, COLOR_BLACK, 1, ASCII5x7, "0.2");
    LCD_Disp_Text(PLOT_X_START + PLOT_WIDTH / 2, PLOT_Y_START + PLOT_HEIGHT + 5, COLOR_BLACK, 1, ASCII5x7, "25");
    LCD_Disp_Text(PLOT_X_START + PLOT_WIDTH - 10, PLOT_Y_START + PLOT_HEIGHT + 5, COLOR_BLACK, 1, ASCII5x7, "50");
}

/**
 * @brief  ����Ƶ����Ӧ����
 */
void Plot_Frequency_Response(void)
{
    if (!plot_updated || gain_table_size < 2)
        return;

    // ������������ (��ɫ)
    for (uint16_t i = 1; i < gain_table_size; i++)
    {
        if (gain_table[i - 1].valid && gain_table[i].valid)
        {
            // ������Ļ����
            uint16_t x1 = PLOT_X_START + ((gain_table[i - 1].frequency - LEARN_MIN_FREQ) * PLOT_WIDTH) / (LEARN_MAX_FREQ - LEARN_MIN_FREQ);
            uint16_t y1 = PLOT_Y_START + PLOT_HEIGHT - (gain_table[i - 1].system_gain * PLOT_HEIGHT) / 2.0f;

            uint16_t x2 = PLOT_X_START + ((gain_table[i].frequency - LEARN_MIN_FREQ) * PLOT_WIDTH) / (LEARN_MAX_FREQ - LEARN_MIN_FREQ);
            uint16_t y2 = PLOT_Y_START + PLOT_HEIGHT - (gain_table[i].system_gain * PLOT_HEIGHT) / 2.0f;

            // �������귶Χ
            if (y1 < PLOT_Y_START)
                y1 = PLOT_Y_START;
            if (y1 > PLOT_Y_START + PLOT_HEIGHT)
                y1 = PLOT_Y_START + PLOT_HEIGHT;
            if (y2 < PLOT_Y_START)
                y2 = PLOT_Y_START;
            if (y2 > PLOT_Y_START + PLOT_HEIGHT)
                y2 = PLOT_Y_START + PLOT_HEIGHT;

            LCD_Draw_Line(x1, y1, x2, y2, COLOR_BLUE);

            // �������ݵ�
            LCD_Draw_Circle_Filled(x2, y2, 1, COLOR_RED);
        }
    }

    plot_updated = 0;
}

/**
 * @brief  ϵͳģʽ�л�
 */
void Switch_System_Mode(SystemMode_t new_mode)
{
    if (new_mode == MODE_LEARNING)
    {
        Learning_Mode_Init();
    }
    else if (new_mode == MODE_WORKING)
    {
        Working_Mode_Init();
    }
}

/**
 * @brief  �����û�����
 */
void Handle_User_Input(void)
{
    // PD12: ѧϰģʽ��ʼ/ֹͣѧϰ
    if (HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_12) == GPIO_PIN_RESET)
    {
        HAL_Delay(20);
        if (HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_12) == GPIO_PIN_RESET)
        {
            if (current_mode == MODE_LEARNING)
            {
                learning_active = !learning_active;
                if (learning_active)
                {
                    learn_current_freq = LEARN_MIN_FREQ;
                    learn_progress = 0;
                    gain_table_size = 0;
                    Clear_Plot_Area();
                    Draw_Plot_Axes();
                    Learning_Mode_Set_Frequency(learn_current_freq);
                    last_learn_time = HAL_GetTick();
                }
            }
            while (HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_12) == GPIO_PIN_RESET)
                ;
            HAL_Delay(20);
        }
    }

    // PD11: ģʽ�л�
    if (HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_11) == GPIO_PIN_RESET)
    {
        HAL_Delay(20);
        if (HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_11) == GPIO_PIN_RESET)
        {
            mode_switch_flag = 1;
            while (HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_11) == GPIO_PIN_RESET)
                ;
            HAL_Delay(20);
        }
    }
}

/**
 * @brief  ��ʾϵͳ״̬
 */
void Display_System_Status(void)
{
    if (current_mode == MODE_LEARNING)
    {
        Learning_Mode_Display();
    }
    else
    {
        Working_Mode_Display();
    }
}

/**
 * @brief  ѧϰģʽ��ʾ
 */
void Learning_Mode_Display(void)
{
    // �����Ϣ��ʾ���򣬱��ְ�ɫ����
    LCD_Draw_Box_Filled(0, 0, 240, PLOT_Y_START - 5, COLOR_WHITE);
    LCD_Draw_Box_Filled(0, PLOT_Y_START + PLOT_HEIGHT + 25, 240, 320, COLOR_WHITE);

    // ����
    LCD_Disp_Text(20, 5, COLOR_BLACK, 2, ASCII5x7, "System Learning Mode");
    LCD_Draw_Line(10, 25, 230, 25, COLOR_GRAY);

    // ��ǰƵ����Ϣ
    if (learn_current_freq >= 1000)
    {
        sprintf(display_string, "Freq: %.1f kHz", learn_current_freq / 1000.0f);
    }
    else
    {
        sprintf(display_string, "Freq: %lu Hz", learn_current_freq);
    }
    LCD_Disp_Text(20, 35, COLOR_BLACK, 1, ASCII5x7, display_string);

    sprintf(display_string, "Status: %s", learning_active ? "LEARNING" : "STOPPED");
    LCD_Disp_Text(130, 35, learning_active ? COLOR_DARK_GREEN : COLOR_RED, 1, ASCII5x7, display_string);

    // ��ǰ����ֵ
    sprintf(display_string, "P-P: %.3fV", current_peak_to_peak);
    LCD_Disp_Text(20, 50, COLOR_BLUE, 1, ASCII5x7, display_string);

    sprintf(display_string, "Gain: %.3f", current_peak_to_peak / LEARN_REFERENCE_VPP);
    LCD_Disp_Text(130, 50, COLOR_BLUE, 1, ASCII5x7, display_string);

    // ѧϰ����
    if (learning_active || gain_table_size > 0)
    {
        sprintf(display_string, "Points: %d/%d", gain_table_size, total_learn_points);
        LCD_Disp_Text(20, 65, COLOR_DARK_GREEN, 1, ASCII5x7, display_string);

        uint32_t progress = (gain_table_size * 100) / total_learn_points;
        sprintf(display_string, "Progress: %lu%%", progress);
        LCD_Disp_Text(130, 65, COLOR_DARK_GREEN, 1, ASCII5x7, display_string);
    }

    // ��ͼ�����·�����Ϣ
    uint16_t info_y = PLOT_Y_START + PLOT_HEIGHT + 30;

    // �˲���ʶ����
    if (gain_table_ready)
    {
        LCD_Disp_Text(20, info_y, COLOR_PURPLE, 1, ASCII5x7, "Filter Analysis:");
        sprintf(display_string, "Type: %s", filter_type_name);
        LCD_Disp_Text(20, info_y + 15, COLOR_BLACK, 1, ASCII5x7, display_string);

        if (cutoff_frequency > 0)
        {
            if (cutoff_frequency >= 1000)
            {
                sprintf(display_string, "Key Freq: %.1f kHz", cutoff_frequency / 1000.0f);
            }
            else
            {
                sprintf(display_string, "Key Freq: %.0f Hz", cutoff_frequency);
            }
            LCD_Disp_Text(20, info_y + 30, COLOR_BLACK, 1, ASCII5x7, display_string);
        }

        sprintf(display_string, "Max Gain: %.3f", max_gain_value);
        LCD_Disp_Text(130, info_y + 15, COLOR_BLACK, 1, ASCII5x7, display_string);
    }

    // ������ʾ
    LCD_Disp_Text(20, info_y + 50, COLOR_GRAY, 1, ASCII5x7, "PD12: Start/Stop  PD11: Switch to Work");

    // ͼ��
    LCD_Draw_Line(20, info_y + 65, 30, info_y + 65, COLOR_BLUE);
    LCD_Disp_Text(35, info_y + 62, COLOR_BLACK, 1, ASCII5x7, "System Gain");

    LCD_Draw_Circle_Filled(120, info_y + 65, 2, COLOR_RED);
    LCD_Disp_Text(125, info_y + 62, COLOR_BLACK, 1, ASCII5x7, "Data Points");
}

/**
 * @brief  ����ģʽ��ʾ
 */
void Working_Mode_Display(void)
{
    // �����ʾ���򣬱��ְ�ɫ����
    LCD_Draw_Box_Filled(5, 80, 235, 320, COLOR_WHITE);

    // ��ҪƵ��
    LCD_Disp_Text(5, 80, COLOR_PURPLE, 1, ASCII5x7, "Dominant Frequency:");
    if (dominant_frequency < 1000)
    {
        sprintf(display_string, "%.0f Hz", dominant_frequency);
    }
    else
    {
        sprintf(display_string, "%.2f kHz", dominant_frequency / 1000.0f);
    }
    LCD_Disp_Text(5, 95, COLOR_BLACK, 2, ASCII5x7, display_string);

    // ϵͳģ����Ϣ
    LCD_Disp_Text(5, 120, COLOR_DARK_GREEN, 1, ASCII5x7, "SYSTEM SIMULATION:");
    sprintf(display_string, "Current Gain: x%.3f", current_simulation_gain);
    LCD_Disp_Text(5, 135, COLOR_BLACK, 1, ASCII5x7, display_string);
    sprintf(display_string, "Target Gain:  x%.3f", target_simulation_gain);
    LCD_Disp_Text(5, 150, COLOR_BLUE, 1, ASCII5x7, display_string);

    // �˲�����Ϣ
    if (gain_table_ready)
    {
        LCD_Disp_Text(5, 170, COLOR_PURPLE, 1, ASCII5x7, "Learned Filter Type:");
        sprintf(display_string, "%s", filter_type_name);
        LCD_Disp_Text(5, 185, COLOR_BLACK, 1, ASCII5x7, display_string);

        if (cutoff_frequency > 0)
        {
            if (cutoff_frequency >= 1000)
            {
                sprintf(display_string, "Key Freq: %.1f kHz", cutoff_frequency / 1000.0f);
            }
            else
            {
                sprintf(display_string, "Key Freq: %.0f Hz", cutoff_frequency);
            }
            LCD_Disp_Text(5, 200, COLOR_ORANGE, 1, ASCII5x7, display_string);
        }
    }

    // �����״̬
    LCD_Disp_Text(5, 220, COLOR_ORANGE, 1, ASCII5x7, "Gain Table Status:");
    sprintf(display_string, "Entries: %d", gain_table_size);
    LCD_Disp_Text(5, 235, COLOR_BLACK, 1, ASCII5x7, display_string);
    sprintf(display_string, "Status: %s", gain_table_ready ? "ACTIVE" : "NOT READY");
    LCD_Disp_Text(5, 250, gain_table_ready ? COLOR_DARK_GREEN : COLOR_RED, 1, ASCII5x7, display_string);

    // ����״̬
    LCD_Disp_Text(5, 270, COLOR_BLUE, 1, ASCII5x7, "Processing Info:");
    sprintf(display_string, "Samples: %lu", processed_samples);
    LCD_Disp_Text(5, 285, COLOR_BLACK, 1, ASCII5x7, display_string);
    sprintf(display_string, "Amplitude: %.1f", dominant_amplitude);
    LCD_Disp_Text(5, 300, COLOR_BLACK, 1, ASCII5x7, display_string);

    // ������ʾ
    LCD_Disp_Text(5, 310, COLOR_GRAY, 1, ASCII5x7, "PD11: Switch to Learning Mode");
}

/**
 * @brief  ADC DMA������ɻص�����
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (current_mode == MODE_WORKING)
    {
        // ����ģʽ��������Ƶ���ݲ��ռ�FFT����
        Working_Mode_Process_Audio_Buffer();

        // �ռ�FFT����
        int samples_to_copy = BUFFER_SIZE;
        if (fft_buffer_index + samples_to_copy > FFT_SIZE)
        {
            samples_to_copy = FFT_SIZE - fft_buffer_index;
        }

        for (int i = 0; i < samples_to_copy; i++)
        {
            fft_data_buffer[fft_buffer_index++] = adc_input_buffer[i];
        }

        if (fft_buffer_index >= FFT_SIZE)
        {
            fft_data_ready = 1;
            fft_buffer_index = 0;
        }
    }
    // ѧϰģʽ�£�ADC����ֱ�����ڲ���������Ҫ���⴦��
}

/**
 * @brief  ADC DMA�������ɻص�����
 */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (current_mode == MODE_WORKING)
    {
        Working_Mode_Process_Audio_Buffer();
    }
}

/**
 * @brief System Clock Configuration
 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 25;
    RCC_OscInitStruct.PLL.PLLN = 168;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 4;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
 * @brief  ����������
 */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
    }
}