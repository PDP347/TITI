/**
 * @file main.c
 * @brief �������ļ� - ��λ������LC��������
 * @author Your Name
 * @date 2024
 */

#define ARM_MATH_CM4
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"
#include "adc.h"
#include "dma.h"
#include "LCDAPI.h"
#include "measurediff.h"  // ������λ����ģ��
#include <stdio.h>
#include <math.h>
#include <string.h>

/* Private defines -----------------------------------------------------------*/
// ��ɫ����
#define COLOR_WHITE 0xFFFF
#define COLOR_BLACK 0x0000
#define COLOR_RED 0xF800
#define COLOR_GREEN 0x07E0
#define COLOR_BLUE 0x001F
#define COLOR_GRAY 0x8410
#define COLOR_YELLOW 0xFFE0
#define COLOR_CYAN 0x07FF
#define COLOR_MAGENTA 0xF81F

// ADC��ض���
#define ADC_BUFFER_SIZE 1000
#define ADC_CHANNELS 2

// ������������
#define SERIES_RESISTANCE 3000.0f  // �������� 3k��
#define PI 3.14159265359f

// ��ʾ���ֶ���
#define LOGO_HEIGHT 25
#define LOGO_Y_OFFSET 5
#define CONTENT_START_Y (LOGO_HEIGHT + LOGO_Y_OFFSET + 10)  // ���ݿ�ʼY���꣺40

// Ԫ�����Ͷ���
typedef enum {
    COMPONENT_UNKNOWN = 0,
    COMPONENT_CAPACITOR,
    COMPONENT_INDUCTOR
} component_type_t;

/* Private variables ---------------------------------------------------------*/
// ��ʾ����
static uint32_t last_display_time = 0;

// ADC DMA������
static uint16_t adc1_buffer[ADC_BUFFER_SIZE];
static uint16_t adc2_buffer[ADC_BUFFER_SIZE];

// ADC��������ṹ��
typedef struct {
    float max_value;
    float min_value;
    float avg_value;
    float rms_value;
    float peak_to_peak;
    float amplitude;  // ��ֵ����
} adc_measurement_t;

// LC��������ṹ��
typedef struct {
    component_type_t component_type;
    float capacitance_nF;     // ����ֵ(nF)
    float inductance_uH;      // ���ֵ(��H)
    float impedance_magnitude; // �迹ģֵ(��)
    float impedance_phase;     // �迹��λ��(��)
    float loss_angle_D;       // ��Ľ�D
    float quality_factor_Q;   // Ʒ������Q
    float esr;                // ��Ч��������(��)
    uint8_t valid;            // ���������Ч��־
} lc_measurement_t;

// ADC�������
static adc_measurement_t adc1_result = {0};
static adc_measurement_t adc2_result = {0};
static lc_measurement_t lc_result = {0};

/* LOGOͼƬ���� -----------------------------------------------------------*/
// NEW_IMAGE - 240��25 pixels
// Width_Bytes: 30, Height: 25
// ��ɫģʽ: ���� (��ɫ��ʾ)
static const char CONTEST_LOGO[750] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x84, 0x00, 0x00, 0x01, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x00, 
    0x80, 0x00, 0x80, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0xC0, 0x08, 0x8C, 0x00, 0x40, 0x01, 0x80, 0x0F, 0xFE, 0x18, 0xFC, 0x18, 0x18, 0x01, 0xC0, 0x00, 
    0xC0, 0x00, 0x03, 0x00, 0x00, 0x7F, 0xFE, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x0C, 
    0xCC, 0x00, 0x40, 0x01, 0x80, 0x0F, 0xFC, 0x0C, 0xFC, 0x1C, 0x18, 0x00, 0xE0, 0x1F, 0xFF, 0x00, 
    0x06, 0x00, 0x00, 0x7F, 0xFE, 0x30, 0x0F, 0x07, 0x87, 0xC3, 0xE0, 0x00, 0x80, 0x06, 0x48, 0x06, 
    0x40, 0x01, 0x84, 0x00, 0x1C, 0x04, 0xCC, 0x0C, 0x18, 0x1F, 0xFE, 0x1F, 0xFF, 0x00, 0x06, 0x07, 
    0x80, 0x66, 0x20, 0x30, 0x1F, 0x8F, 0x87, 0xE3, 0xE0, 0x00, 0x80, 0x06, 0x58, 0x04, 0x40, 0x1F, 
    0xFC, 0x00, 0x18, 0x04, 0xCC, 0x04, 0x18, 0x1F, 0xFE, 0x11, 0x13, 0x00, 0x06, 0x0F, 0xC0, 0x7E, 
    0x20, 0x30, 0x31, 0x8C, 0xCC, 0x66, 0x30, 0x00, 0x80, 0x1F, 0xFF, 0x0C, 0xC0, 0x11, 0x8C, 0x00, 
    0x30, 0x00, 0x8C, 0x00, 0x18, 0x03, 0x18, 0x1F, 0xFF, 0x00, 0x06, 0x1C, 0xE0, 0x7E, 0xFC, 0x30, 
    0x31, 0x98, 0xCC, 0x66, 0x30, 0x00, 0x80, 0x1F, 0xFF, 0x0F, 0xFE, 0x11, 0x8C, 0x00, 0x60, 0x00, 
    0x8C, 0x00, 0x18, 0x23, 0x30, 0x07, 0x34, 0x00, 0x04, 0x18, 0x60, 0x66, 0xFC, 0x30, 0x01, 0x98, 
    0x40, 0x60, 0x30, 0x3F, 0xFE, 0x10, 0x03, 0x0F, 0xFE, 0x11, 0x8C, 0x00, 0xC0, 0x3D, 0x8F, 0x01, 
    0xFF, 0xBF, 0xFF, 0x07, 0x34, 0x00, 0x04, 0x18, 0x00, 0x7E, 0x8C, 0x10, 0x01, 0x98, 0x60, 0x60, 
    0x30, 0x3F, 0xFE, 0x10, 0x03, 0x08, 0x40, 0x1F, 0xFC, 0x00, 0x40, 0x3D, 0x06, 0x3D, 0xFF, 0x80, 
    0x00, 0x07, 0xFC, 0x00, 0x0C, 0x30, 0x00, 0x7E, 0xBC, 0x18, 0x01, 0x98, 0x60, 0x60, 0x60, 0x00, 
    0xC0, 0x17, 0xFB, 0x18, 0x40, 0x1F, 0xFC, 0x3F, 0xFF, 0x09, 0x00, 0x2C, 0x18, 0x04, 0x00, 0x01, 
    0x30, 0x00, 0x0C, 0x30, 0x00, 0x00, 0xAC, 0x18, 0x03, 0x18, 0x60, 0xC1, 0xC0, 0x00, 0xC0, 0x07, 
    0xF8, 0x18, 0x40, 0x11, 0x8C, 0x3F, 0xFF, 0x09, 0xFE, 0x0C, 0x18, 0x07, 0xFC, 0x3F, 0xFF, 0x00, 
    0x0C, 0x30, 0x00, 0xFE, 0xAC, 0x18, 0x07, 0x18, 0x61, 0x81, 0xE0, 0x01, 0xE0, 0x00, 0x30, 0x10, 
    0xC0, 0x11, 0x8C, 0x00, 0x40, 0x09, 0xFC, 0x0C, 0x18, 0x04, 0x0C, 0x07, 0x0C, 0x00, 0x0C, 0x30, 
    0x00, 0xFE, 0xAC, 0x18, 0x0E, 0x18, 0x63, 0x80, 0x30, 0x01, 0xE0, 0x00, 0x60, 0x0F, 0xFC, 0x11, 
    0x8C, 0x00, 0x40, 0x08, 0x4C, 0x0C, 0x18, 0x04, 0x0C, 0x07, 0xFC, 0x00, 0x04, 0x30, 0x00, 0x08, 
    0xAC, 0x10, 0x0C, 0x18, 0x47, 0x00, 0x30, 0x01, 0x20, 0x3F, 0xD5, 0x00, 0xC4, 0x1F, 0xFC, 0x00, 
    0x40, 0x08, 0x6C, 0x0C, 0x18, 0x07, 0xFC, 0x1F, 0xFF, 0x80, 0x04, 0x30, 0x00, 0x2A, 0xAC, 0x30, 
    0x18, 0x18, 0xC6, 0x04, 0x30, 0x03, 0x30, 0x3F, 0xFF, 0x00, 0x40, 0x1F, 0xFC, 0x00, 0x40, 0x08, 
    0x68, 0x0D, 0x18, 0x07, 0xFC, 0x3B, 0x5B, 0x80, 0x06, 0x18, 0x60, 0x6E, 0x78, 0x30, 0x10, 0x18, 
    0xCC, 0x06, 0x30, 0x02, 0x18, 0x00, 0xC0, 0x00, 0x40, 0x01, 0x80, 0x00, 0x40, 0x0A, 0x38, 0x0D, 
    0x18, 0x01, 0xA0, 0x32, 0xD8, 0x00, 0x06, 0x18, 0x60, 0x68, 0x4C, 0x30, 0x3F, 0x8C, 0xCF, 0xE6, 
    0x30, 0x06, 0x18, 0x00, 0x40, 0x00, 0x40, 0x01, 0x83, 0x00, 0x40, 0x0E, 0x38, 0x0F, 0x18, 0x03, 
    0x21, 0x02, 0xD8, 0x00, 0x06, 0x1C, 0xC0, 0x79, 0xCC, 0x30, 0x3F, 0xCF, 0x8F, 0xE3, 0xF0, 0x0C, 
    0x0C, 0x00, 0x40, 0x00, 0x40, 0x01, 0x83, 0x00, 0x40, 0x0C, 0x7C, 0x0E, 0x18, 0x03, 0x23, 0x03, 
    0xF8, 0x00, 0x06, 0x0F, 0xC0, 0x79, 0x84, 0x30, 0x3F, 0x87, 0x0F, 0xE1, 0xC0, 0x1C, 0x07, 0x00, 
    0x40, 0x3F, 0xFF, 0x01, 0x83, 0x00, 0xC0, 0x0D, 0xEF, 0x8C, 0x18, 0x0E, 0x33, 0x03, 0xBC, 0x00, 
    0x03, 0x07, 0x80, 0xDF, 0x0E, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x38, 0x03, 0x03, 0xC0, 0x3F, 
    0xFF, 0x00, 0xFE, 0x03, 0xC0, 0x0B, 0x83, 0x0C, 0x18, 0x3C, 0x3E, 0x1F, 0x0E, 0x00, 0x03, 0x00, 
    0x00, 0x8F, 0xFE, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x02, 0x01, 0xC0, 0x00, 0x00, 0x00, 
    0xFE, 0x01, 0x80, 0x01, 0x01, 0x00, 0x18, 0x18, 0x00, 0x0E, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void Display_All_Info(void);
void Display_Logo(void);
void ADC_Calculate_Values(uint16_t* buffer, uint16_t size, adc_measurement_t* result);
void ADC_Init_All(void);
void ADC_Start_Conversion(void);
void Calculate_LC_Parameters(void);
float Calculate_Impedance_Magnitude(float voltage_amplitude, float current_amplitude);
component_type_t Determine_Component_Type(float phase_deg);

/* Private user code ---------------------------------------------------------*/

/**
 * @brief ��ʾLOGOͼƬ
 */
void Display_Logo(void)
{
    // �ڶ�����ʾLOGO��ʹ����ɫ
    LCD_Disp_DotGrid(0, LOGO_Y_OFFSET, CONTEST_LOGO, 30, LOGO_HEIGHT, COLOR_BLUE);
}

/**
 * @brief �����迹ģֵ
 */
float Calculate_Impedance_Magnitude(float voltage_amplitude, float current_amplitude)
{
    if (current_amplitude > 0.001f)  // �������
    {
        return voltage_amplitude / current_amplitude;
    }
    return 0.0f;
}

/**
 * @brief ������λ���ж�Ԫ������
 */
component_type_t Determine_Component_Type(float phase_deg)
{
    // ����λ�Ǳ�׼����-180��180�ȷ�Χ
    while (phase_deg > 180.0f) phase_deg -= 360.0f;
    while (phase_deg < -180.0f) phase_deg += 360.0f;
    
    if (phase_deg > 45.0f && phase_deg < 135.0f)
    {
        return COMPONENT_INDUCTOR;  // ��У���ѹ��ǰ����
    }
    else if (phase_deg > -135.0f && phase_deg < -45.0f)
    {
        return COMPONENT_CAPACITOR; // ���ݣ���ѹ�ͺ����
    }
    else
    {
        return COMPONENT_UNKNOWN;   // δ֪�������
    }
}

/**
 * @brief ����LC����
 */
void Calculate_LC_Parameters(void)
{
    phase_measurement_result_t phase_result;
    MeasureDiff_GetResult(&phase_result);
    
    // �������Ƿ��ȶ�
    if (!phase_result.system_stable || phase_result.estimated_frequency < 100.0f)
    {
        lc_result.valid = 0;
        return;
    }
    
    // �����ѹ�͵�������
    float voltage_amplitude = adc1_result.amplitude;  // CH1: ��ѹ
    float current_amplitude = adc2_result.amplitude / SERIES_RESISTANCE;  // CH2: ���� = V_R / R
    
    // �����迹ģֵ
    lc_result.impedance_magnitude = Calculate_Impedance_Magnitude(voltage_amplitude, current_amplitude);
    lc_result.impedance_phase = phase_result.phase_difference_deg;
    
    // �ж�Ԫ������
    lc_result.component_type = Determine_Component_Type(lc_result.impedance_phase);
    
    if (lc_result.impedance_magnitude < 1.0f || lc_result.impedance_magnitude > 100000.0f)
    {
        lc_result.valid = 0;
        return;
    }
    
    float frequency = phase_result.estimated_frequency;
    float omega = 2.0f * PI * frequency;
    float phase_rad = lc_result.impedance_phase * PI / 180.0f;
    
    // �����޹������͵������
    float reactance = lc_result.impedance_magnitude * sinf(phase_rad);
    float resistance = lc_result.impedance_magnitude * cosf(phase_rad);
    
    // ����ESR����Ч�������裩
    lc_result.esr = fabs(resistance);
    
    if (lc_result.component_type == COMPONENT_CAPACITOR)
    {
        // ���ݼ���: Xc = 1/(��C), C = 1/(��*|Xc|)
        if (fabs(reactance) > 1.0f)
        {
            lc_result.capacitance_nF = 1.0f / (omega * fabs(reactance)) * 1e9f;  // ת��ΪnF
            lc_result.inductance_uH = 0.0f;
            
            // ������ĽǺ�Ʒ������
            if (fabs(reactance) > 0.001f)
            {
                lc_result.loss_angle_D = atanf(resistance / fabs(reactance)) * 180.0f / PI;
                lc_result.quality_factor_Q = fabs(reactance) / resistance;
            }
        }
        else
        {
            lc_result.valid = 0;
            return;
        }
    }
    else if (lc_result.component_type == COMPONENT_INDUCTOR)
    {
        // ��м���: Xl = ��L, L = Xl/��
        if (fabs(reactance) > 1.0f)
        {
            lc_result.inductance_uH = fabs(reactance) / omega * 1e6f;  // ת��Ϊ��H
            lc_result.capacitance_nF = 0.0f;
            
            // ������ĽǺ�Ʒ������
            if (resistance > 0.001f)
            {
                lc_result.loss_angle_D = atanf(resistance / fabs(reactance)) * 180.0f / PI;
                lc_result.quality_factor_Q = fabs(reactance) / resistance;
            }
        }
        else
        {
            lc_result.valid = 0;
            return;
        }
    }
    else
    {
        lc_result.capacitance_nF = 0.0f;
        lc_result.inductance_uH = 0.0f;
        lc_result.loss_angle_D = 0.0f;
        lc_result.quality_factor_Q = 0.0f;
        lc_result.valid = 0;
        return;
    }
    
    // ��Χ���
    if ((lc_result.component_type == COMPONENT_CAPACITOR && 
         (lc_result.capacitance_nF < 1.0f || lc_result.capacitance_nF > 100.0f)) ||
        (lc_result.component_type == COMPONENT_INDUCTOR && 
         (lc_result.inductance_uH < 10.0f || lc_result.inductance_uH > 100.0f)))
    {
        lc_result.valid = 0;
        return;
    }
    
    lc_result.valid = 1;
}

/**
 * @brief ����ADC����ֵ(���ֵ����Сֵ��ƽ��ֵ��RMS�����ֵ������)
 */
void ADC_Calculate_Values(uint16_t* buffer, uint16_t size, adc_measurement_t* result)
{
    uint32_t sum = 0;
    uint64_t sum_squares = 0;
    uint16_t max_raw = 0;
    uint16_t min_raw = 4095;
    
    // ��������������ͳ��ֵ
    for (uint16_t i = 0; i < size; i++)
    {
        uint16_t value = buffer[i];
        
        // �ۼ����
        sum += value;
        sum_squares += (uint64_t)value * value;
        
        // ���������Сֵ
        if (value > max_raw) max_raw = value;
        if (value < min_raw) min_raw = value;
    }
    
    // ת��Ϊ��ѹֵ (����ο���ѹΪ3.3V, 12λADC)
    const float voltage_ref = 3.3f;
    const float adc_resolution = 4095.0f;
    
    result->max_value = (max_raw / adc_resolution) * voltage_ref;
    result->min_value = (min_raw / adc_resolution) * voltage_ref;
    result->avg_value = (sum / (float)size / adc_resolution) * voltage_ref;
    result->peak_to_peak = result->max_value - result->min_value;
    result->amplitude = result->peak_to_peak / 2.0f;  // ��ֵ����
    
    // ����RMSֵ
    float mean_squares = sum_squares / (float)size;
    result->rms_value = sqrtf(mean_squares / (adc_resolution * adc_resolution)) * voltage_ref;
}

/**
 * @brief ��ʼ������ADC��DMA
 */
void ADC_Init_All(void)
{
    MX_DMA_Init();
    MX_ADC1_Init();
    MX_ADC2_Init();
    MX_TIM3_Init();
}

/**
 * @brief ����ADCת��
 */
void ADC_Start_Conversion(void)
{
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc1_buffer, ADC_BUFFER_SIZE);
    HAL_ADC_Start_DMA(&hadc2, (uint32_t*)adc2_buffer, ADC_BUFFER_SIZE);
    HAL_TIM_Base_Start(&htim3);
}

/**
 * @brief ��ʾ������Ϣ(�Ż����֣�����LOGO)
 */
void Display_All_Info(void)
{
    char buffer[50];
    phase_measurement_result_t result;
    
    // ��ȡ��λ�������
    MeasureDiff_GetResult(&result);
    
    // ����ADC����ֵ
    ADC_Calculate_Values(adc1_buffer, ADC_BUFFER_SIZE, &adc1_result);
    ADC_Calculate_Values(adc2_buffer, ADC_BUFFER_SIZE, &adc2_result);
    
    // ����LC����
    Calculate_LC_Parameters();
    
    // ����
    LCD_Draw_Box_Filled(0, 0, 240, 320, COLOR_WHITE);
    
    // === ��ʾLOGO�������� ===
    Display_Logo();
    
    // === ����ͷָ��� ===
    LCD_Disp_Text(50, CONTENT_START_Y, COLOR_BLACK, 2, ASCII5x7, "LC Meter v2.0");
    LCD_Draw_Line(10, CONTENT_START_Y + 20, 230, CONTENT_START_Y + 20, COLOR_GRAY);
    
    // === Ƶ�ʺ���λ��Ϣ ===
    sprintf(buffer, "Freq: %.1f Hz", result.estimated_frequency);
    LCD_Disp_Text(20, CONTENT_START_Y + 30, COLOR_BLUE, 1, ASCII5x7, buffer);
    
    sprintf(buffer, "Phase: %.1f��", result.phase_difference_deg);
    LCD_Disp_Text(130, CONTENT_START_Y + 30, COLOR_RED, 1, ASCII5x7, buffer);
    
    if (result.system_stable)
        LCD_Disp_Text(200, CONTENT_START_Y + 30, COLOR_GREEN, 1, ASCII5x7, "OK");
    else
        LCD_Disp_Text(200, CONTENT_START_Y + 30, COLOR_RED, 1, ASCII5x7, "...");
    
    LCD_Draw_Line(10, CONTENT_START_Y + 45, 230, CONTENT_START_Y + 45, COLOR_GRAY);
    
    // === LC������� ===
    if (lc_result.valid)
    {
        if (lc_result.component_type == COMPONENT_CAPACITOR)
        {
            LCD_Disp_Text(20, CONTENT_START_Y + 55, COLOR_BLACK, 1, ASCII5x7, "CAPACITOR:");
            sprintf(buffer, "C = %.2f nF", lc_result.capacitance_nF);
            LCD_Disp_Text(20, CONTENT_START_Y + 70, COLOR_BLUE, 1, ASCII5x7, buffer);
        }
        else if (lc_result.component_type == COMPONENT_INDUCTOR)
        {
            LCD_Disp_Text(20, CONTENT_START_Y + 55, COLOR_BLACK, 1, ASCII5x7, "INDUCTOR:");
            sprintf(buffer, "L = %.1f ��H", lc_result.inductance_uH);
            LCD_Disp_Text(20, CONTENT_START_Y + 70, COLOR_BLUE, 1, ASCII5x7, buffer);
        }
        
        sprintf(buffer, "D = %.3f", lc_result.loss_angle_D);
        LCD_Disp_Text(130, CONTENT_START_Y + 70, COLOR_RED, 1, ASCII5x7, buffer);
        
        sprintf(buffer, "Q = %.1f", lc_result.quality_factor_Q);
        LCD_Disp_Text(20, CONTENT_START_Y + 85, COLOR_GREEN, 1, ASCII5x7, buffer);
        
        sprintf(buffer, "ESR = %.1f��", lc_result.esr);
        LCD_Disp_Text(130, CONTENT_START_Y + 85, COLOR_MAGENTA, 1, ASCII5x7, buffer);
        
        sprintf(buffer, "|Z| = %.1f��", lc_result.impedance_magnitude);
        LCD_Disp_Text(20, CONTENT_START_Y + 100, COLOR_CYAN, 1, ASCII5x7, buffer);
    }
    else
    {
        LCD_Disp_Text(20, CONTENT_START_Y + 55, COLOR_RED, 1, ASCII5x7, "NO COMPONENT DETECTED");
        LCD_Disp_Text(20, CONTENT_START_Y + 70, COLOR_RED, 1, ASCII5x7, "or OUT OF RANGE");
    }
    
    LCD_Draw_Line(10, CONTENT_START_Y + 115, 230, CONTENT_START_Y + 115, COLOR_GRAY);
    
    // === �򻯵�ADC��Ϣ ===
    LCD_Disp_Text(20, CONTENT_START_Y + 125, COLOR_BLACK, 1, ASCII5x7, "ADC Channels:");
    
    sprintf(buffer, "V: %.3fV(pp)", adc1_result.peak_to_peak);
    LCD_Disp_Text(20, CONTENT_START_Y + 140, COLOR_BLUE, 1, ASCII5x7, buffer);
    
    sprintf(buffer, "I: %.3fV(pp)", adc2_result.peak_to_peak);
    LCD_Disp_Text(130, CONTENT_START_Y + 140, COLOR_RED, 1, ASCII5x7, buffer);
    
    sprintf(buffer, "V_rms: %.3fV", adc1_result.rms_value);
    LCD_Disp_Text(20, CONTENT_START_Y + 155, COLOR_GREEN, 1, ASCII5x7, buffer);
    
    sprintf(buffer, "I_rms: %.3fV", adc2_result.rms_value);
    LCD_Disp_Text(130, CONTENT_START_Y + 155, COLOR_GREEN, 1, ASCII5x7, buffer);
    
    // === ������Χ˵�� ===
    LCD_Draw_Line(10, CONTENT_START_Y + 170, 230, CONTENT_START_Y + 170, COLOR_GRAY);
    LCD_Disp_Text(20, CONTENT_START_Y + 180, COLOR_GRAY, 1, ASCII5x7, "Range: C(1-100nF) L(10-100��H)");
    LCD_Disp_Text(20, CONTENT_START_Y + 195, COLOR_GRAY, 1, ASCII5x7, "Series R = 3k��");
    
    // �ײ�״̬��
    LCD_Draw_Line(10, CONTENT_START_Y + 210, 230, CONTENT_START_Y + 210, COLOR_GRAY);
    sprintf(buffer, "Update: %lu ms", HAL_GetTick());
    LCD_Disp_Text(20, CONTENT_START_Y + 220, COLOR_GRAY, 1, ASCII5x7, buffer);
}

/**
 * @brief ADCת����ɻص�����
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    // ADCת����ɺ�Ĵ���
}

/**
 * @brief HAL�ⶨʱ�����벶���жϻص�����
 */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    MeasureDiff_TIM_IC_CaptureCallback(htim);
}

/**
 * @brief HAL�ⶨʱ������жϻص�����
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    MeasureDiff_TIM_PeriodElapsedCallback(htim);
}

int main(void)
{
    /* MCU Configuration--------------------------------------------------------*/
    HAL_Init();
    SystemClock_Config();

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_TIM9_Init();
    MX_SPI2_Init();
    
    /* Initialize ADC and DMA */
    ADC_Init_All();
    
    /* Initialize LCD */
    LCD_Init();

    /* Initialize phase measurement module */
    MeasureDiff_Init();
    
    /* ����ADCת�� */
    ADC_Start_Conversion();
    
    /* ��ʼ����ʾ */
    Display_All_Info();
    last_display_time = HAL_GetTick();

    /* Infinite loop */
    while (1)
    {
        // ������λ����
        MeasureDiff_Process();
        
        // ��ʱ������ʾ
        if (HAL_GetTick() - last_display_time >= PHASE_UPDATE_INTERVAL)
        {
            Display_All_Info();
            last_display_time = HAL_GetTick();
        }
        
        // ��ѭ���ӳ�
        HAL_Delay(20);
    }
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    /** Configure the main internal regulator output voltage */
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /** Initializes the RCC Oscillators according to the specified parameters
     * in the RCC_OscInitTypeDef structure.
     */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 25;
    RCC_OscInitStruct.PLL.PLLN = 168;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 4;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
 * @brief ����������
 */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
    }
}