/*
 * 互相关法相位差测量实现
 * 在原有FFT方法基础上添加互相关方法
 */

#include "ti_msp_dl_config.h"
#include "arm_const_structs.h"
#include "arm_math.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* FFT configuration */
#define FFT_SIZE (256)
#define ADC_SAMPLE_SIZE (500)

/* 互相关配置 */
#define CORRELATION_SIZE (FFT_SIZE)
#define MAX_DELAY_SAMPLES (FFT_SIZE / 4)  // 最大延时样本数

/* FFT defines */
#define IFFTFLAG 0
#define BITREVERSE 1

/* ADC reference voltage and resolution */
#define ADC_VREF (3.3f)
#define ADC_RESOLUTION (4096)

/* 采样频率 (Hz) - 根据您的ADC配置调整 */
#define SAMPLING_FREQUENCY (200000.0f)

/* ADC sample buffers */
uint16_t gADC0Samples[ADC_SAMPLE_SIZE];
uint16_t gADC1Samples[ADC_SAMPLE_SIZE];
volatile bool gCheckADC0;
volatile bool gCheckADC1;

/* FFT buffers */
volatile int16_t gFFTInput0[FFT_SIZE * 2];
volatile int16_t gFFTInput1[FFT_SIZE * 2];
volatile int16_t gFFTOutput0[FFT_SIZE];
volatile int16_t gFFTOutput1[FFT_SIZE];

/* 互相关缓冲区 */
float32_t gSignal0[CORRELATION_SIZE];        // 信号0 (去直流偏移后)
float32_t gSignal1[CORRELATION_SIZE];        // 信号1 (去直流偏移后)
float32_t gCorrelationResult[CORRELATION_SIZE * 2 - 1];  // 互相关结果

/* FFT results */
volatile uint32_t gFFTmaxValue0, gFFTmaxValue1;
volatile uint32_t gFFTmaxFreqIndex0, gFFTmaxFreqIndex1;
volatile float gPhase0_FFT, gPhase1_FFT, gPhaseDiff_FFT;
volatile float gRealAmplitude0, gRealAmplitude1;

/* 互相关结果 */
volatile float gPhaseDiff_Corr;              // 互相关法计算的相位差
volatile float gDominantFreq;                // 主要频率成分
volatile int32_t gMaxDelayIndex;             // 最大相关值对应的延时索引

/* 测量方法选择 */
typedef enum {
    METHOD_FFT = 0,
    METHOD_CORRELATION = 1,
    METHOD_BOTH = 2
} measurement_method_t;

measurement_method_t gMeasurementMethod = METHOD_BOTH;

// UART发送缓冲区
char uart_buffer[512];

// 函数声明
void UART_send_string(const char* str);
void configure_adc_dma(void);
void perform_fft_analysis(void);
void perform_correlation_analysis(void);
void prepare_fft_data(uint16_t* adc_samples, int16_t* fft_input, uint16_t offset);
void prepare_correlation_data(uint16_t* adc_samples, float32_t* output, uint16_t offset);
void output_results(void);
float calculate_dc_offset(uint16_t* samples, uint16_t start, uint16_t count);
float calculate_phase_fft(int16_t real, int16_t imag);
float calculate_real_amplitude(uint32_t fft_magnitude);
float calculate_phase_difference(float phase1, float phase2);
float find_dominant_frequency_fft(void);
float calculate_phase_from_correlation(int32_t delay_samples, float frequency);

int main(void)
{
    SYSCFG_DL_init();

    /* 初始化UART */
    UART_send_string("ADC Dual Channel Phase Difference Measurement\r\n");
    UART_send_string("Methods: FFT + Cross-Correlation\r\n");
    UART_send_string("Format: [Method] Freq(Hz), Amplitude(V), Phase Diff(deg)\r\n");
    UART_send_string("===============================================================\r\n");
    
    /* 配置ADC和DMA */
    configure_adc_dma();
    
    /* 添加延时确保ADC稳定 */
    DL_Common_delayCycles(100000);

    static bool adc0_ready = false;
    static bool adc1_ready = false;

    while (1) {
        if (gCheckADC0) {
            gCheckADC0 = false;
            adc0_ready = true;
            
            DL_ADC12_setDMASamplesCnt(ADC12_0_INST, 1);
            DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
            DL_ADC12_startConversion(ADC12_0_INST);
        }
        
        if (gCheckADC1) {
            gCheckADC1 = false;
            adc1_ready = true;
            
            DL_ADC12_setDMASamplesCnt(ADC12_1_INST, 1);
            DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);
            DL_ADC12_startConversion(ADC12_1_INST);
        }
        
        // 当两路都有新数据时，进行分析
        if (adc0_ready && adc1_ready) {
            if (gMeasurementMethod == METHOD_FFT || gMeasurementMethod == METHOD_BOTH) {
                perform_fft_analysis();
            }
            
            if (gMeasurementMethod == METHOD_CORRELATION || gMeasurementMethod == METHOD_BOTH) {
                perform_correlation_analysis();
            }
            
            output_results();
            
            adc0_ready = false;
            adc1_ready = false;
        }
    }
}

// 准备互相关数据：去直流偏移并转换为float32格式
void prepare_correlation_data(uint16_t* adc_samples, float32_t* output, uint16_t offset)
{
    // 计算直流偏移
    float dc_offset = calculate_dc_offset(adc_samples, offset, CORRELATION_SIZE);
    
    // 转换为float32并去除直流偏移
    for (uint16_t i = 0; i < CORRELATION_SIZE; i++) {
        output[i] = (float32_t)(adc_samples[i + offset]) - dc_offset;
    }
}

// 执行互相关分析
void perform_correlation_analysis(void)
{
    // 准备互相关数据
    prepare_correlation_data(gADC0Samples, gSignal0, 0);
    prepare_correlation_data(gADC1Samples, gSignal1, 0);
    
    // 执行互相关计算
    // arm_correlate_f32(pSrcA, srcALen, pSrcB, srcBLen, pDst)
    // 结果长度 = srcALen + srcBLen - 1
    arm_correlate_f32(gSignal0, CORRELATION_SIZE, gSignal1, CORRELATION_SIZE, gCorrelationResult);
    
    // 找到最大相关值及其索引
    float32_t maxCorrelation;
    uint32_t maxIndex;
    arm_max_f32(gCorrelationResult, CORRELATION_SIZE * 2 - 1, &maxCorrelation, &maxIndex);
    
    // 计算延时样本数 (相对于零延时的偏移)
    // 零延时位置在 (CORRELATION_SIZE - 1)
    gMaxDelayIndex = (int32_t)maxIndex - (CORRELATION_SIZE - 1);
    
    // 限制延时范围以避免噪声影响
    if (abs(gMaxDelayIndex) > MAX_DELAY_SAMPLES) {
        // 如果延时过大，可能是噪声，设置为0
        gMaxDelayIndex = 0;
    }
    
    // 从FFT结果获取主要频率（需要先执行FFT分析）
    gDominantFreq = find_dominant_frequency_fft();
    
    // 计算相位差
    gPhaseDiff_Corr = calculate_phase_from_correlation(gMaxDelayIndex, gDominantFreq);
}

// 从FFT结果找到主要频率
float find_dominant_frequency_fft(void)
{
    // 如果FFT分析已经完成，使用FFT结果
    if (gFFTmaxFreqIndex0 > 0 && gFFTmaxFreqIndex1 > 0) {
        float freq_resolution = SAMPLING_FREQUENCY / FFT_SIZE;
        // 使用两个通道中幅值较大的频率
        if (gFFTmaxValue0 > gFFTmaxValue1) {
            return gFFTmaxFreqIndex0 * freq_resolution;
        } else {
            return gFFTmaxFreqIndex1 * freq_resolution;
        }
    }
    
    // 如果没有FFT结果，返回默认值
    return 1000.0f; // 1kHz默认值
}

// 根据延时样本数和频率计算相位差
float calculate_phase_from_correlation(int32_t delay_samples, float frequency)
{
    if (frequency <= 0) {
        return 0.0f;
    }
    
    // 计算时间延迟
    float time_delay = (float)delay_samples / SAMPLING_FREQUENCY;
    
    // 计算相位差 (弧度)
    float phase_diff = 2.0f * M_PI * frequency * time_delay;
    
    // 将相位差归一化到 [-π, π] 范围
    while (phase_diff > M_PI) {
        phase_diff -= 2.0f * M_PI;
    }
    while (phase_diff < -M_PI) {
        phase_diff += 2.0f * M_PI;
    }
    
    return phase_diff;
}

// 输出分析结果
void output_results(void)
{
    float freq_resolution = SAMPLING_FREQUENCY / FFT_SIZE;
    
    if (gMeasurementMethod == METHOD_FFT || gMeasurementMethod == METHOD_BOTH) {
        // FFT结果
        float dominant_freq0 = gFFTmaxFreqIndex0 * freq_resolution;
        float dominant_freq1 = gFFTmaxFreqIndex1 * freq_resolution;
        float phase0_deg = gPhase0_FFT * 180.0f / M_PI;
        float phase1_deg = gPhase1_FFT * 180.0f / M_PI;
        float phase_diff_deg = gPhaseDiff_FFT * 180.0f / M_PI;
        
        sprintf(uart_buffer, "[FFT] ADC0: %.1fHz,%.3fV,%.1f°  ADC1: %.1fHz,%.3fV,%.1f°  Diff: %.1f°\r\n", 
                dominant_freq0, gRealAmplitude0, phase0_deg,
                dominant_freq1, gRealAmplitude1, phase1_deg,
                phase_diff_deg);
        UART_send_string(uart_buffer);
    }
    
    if (gMeasurementMethod == METHOD_CORRELATION || gMeasurementMethod == METHOD_BOTH) {
        // 互相关结果
        float time_delay = (float)gMaxDelayIndex / SAMPLING_FREQUENCY;
        float phase_diff_deg = gPhaseDiff_Corr * 180.0f / M_PI;
        
        sprintf(uart_buffer, "[CORR] Freq: %.1fHz  Delay: %ld samples(%.3fμs)  Phase Diff: %.1f°\r\n", 
                gDominantFreq, gMaxDelayIndex, time_delay * 1000000.0f, phase_diff_deg);
        UART_send_string(uart_buffer);
    }
    
    if (gMeasurementMethod == METHOD_BOTH) {
        // 比较两种方法的结果
        float fft_deg = gPhaseDiff_FFT * 180.0f / M_PI;
        float corr_deg = gPhaseDiff_Corr * 180.0f / M_PI;
        float difference = fabsf(fft_deg - corr_deg);
        
        sprintf(uart_buffer, "[COMP] FFT: %.1f°  CORR: %.1f°  Diff: %.1f°\r\n", 
                fft_deg, corr_deg, difference);
        UART_send_string(uart_buffer);
    }
    
    UART_send_string("---\r\n");
}

// 以下是原有的FFT相关函数，保持不变
void configure_adc_dma(void)
{
    gCheckADC0 = false;
    gCheckADC1 = false;
    
    DL_ADC12_setDMASamplesCnt(ADC12_0_INST, ADC_SAMPLE_SIZE);
    DL_ADC12_setDMASamplesCnt(ADC12_1_INST, ADC_SAMPLE_SIZE);
    
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_0_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);

    DL_DMA_setSrcAddr(DMA, DMA_CH1_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_1_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);

    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    NVIC_EnableIRQ(ADC12_1_INST_INT_IRQN);
    NVIC_SetPriority(ADC12_0_INST_INT_IRQN, 1);
    NVIC_SetPriority(ADC12_1_INST_INT_IRQN, 1);
    
    DL_ADC12_clearInterruptStatus(ADC12_0_INST, DL_ADC12_INTERRUPT_DMA_DONE);
    DL_ADC12_clearInterruptStatus(ADC12_1_INST, DL_ADC12_INTERRUPT_DMA_DONE);


    DL_ADC12_startConversion(ADC12_0_INST);
    DL_ADC12_startConversion(ADC12_1_INST);

}

void ADC12_0_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_0_INST);
    if (interruptStatus == DL_ADC12_IIDX_DMA_DONE) {
        gCheckADC0 = true;
    }
}

void ADC12_1_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_1_INST);
    if (interruptStatus == DL_ADC12_IIDX_DMA_DONE) {
        gCheckADC1 = true;
    }
}

void UART_send_string(const char* str)
{
    while (*str) {
        while (DL_UART_Main_isBusy(UART_0_INST));
        DL_UART_Main_transmitData(UART_0_INST, *str++);
    }
}

float calculate_dc_offset(uint16_t* samples, uint16_t start, uint16_t count)
{
    uint32_t sum = 0;
    for (uint16_t i = start; i < start + count; i++) {
        sum += samples[i];
    }
    return (float)sum / count;
}

void prepare_fft_data(uint16_t* adc_samples, int16_t* fft_input, uint16_t offset)
{
    float dc_offset = calculate_dc_offset(adc_samples, offset, FFT_SIZE);
    
    for (uint16_t i = 0; i < FFT_SIZE; i++) {
        int16_t sample = (int16_t)(adc_samples[i + offset] - dc_offset);
        fft_input[2 * i] = sample;
        fft_input[2 * i + 1] = 0;
    }
}

float calculate_real_amplitude(uint32_t fft_magnitude)
{
    float normalized_magnitude = (float)fft_magnitude / (FFT_SIZE / 2);
    float voltage_amplitude = (normalized_magnitude * ADC_VREF) / ADC_RESOLUTION;
    return voltage_amplitude;
}

float calculate_phase_difference(float phase1, float phase2)
{
    float diff = phase2 - phase1;
    while (diff > M_PI) diff -= 2 * M_PI;
    while (diff < -M_PI) diff += 2 * M_PI;
    return diff;
}

void perform_fft_analysis(void)
{
    // 准备FFT输入数据
    prepare_fft_data(gADC0Samples, (int16_t*)gFFTInput0, 0);
    prepare_fft_data(gADC1Samples, (int16_t*)gFFTInput1, 0);
    
    // 执行FFT - ADC0
    arm_cfft_q15(&arm_cfft_sR_q15_len256, (q15_t*)gFFTInput0, IFFTFLAG, BITREVERSE);
    arm_cmplx_mag_q15((q15_t*)gFFTInput0, (q15_t*)gFFTOutput0, FFT_SIZE);
    
    arm_max_q15((q15_t*)&gFFTOutput0[1], FFT_SIZE/2 - 1, (q15_t*)&gFFTmaxValue0, &gFFTmaxFreqIndex0);
    gFFTmaxFreqIndex0 += 1;
    
    gRealAmplitude0 = calculate_real_amplitude(gFFTmaxValue0);
    
    int16_t real0 = gFFTInput0[2 * gFFTmaxFreqIndex0];
    int16_t imag0 = gFFTInput0[2 * gFFTmaxFreqIndex0 + 1];
    gPhase0_FFT = calculate_phase_fft(real0, imag0);
    
    // 执行FFT - ADC1
    arm_cfft_q15(&arm_cfft_sR_q15_len256, (q15_t*)gFFTInput1, IFFTFLAG, BITREVERSE);
    arm_cmplx_mag_q15((q15_t*)gFFTInput1, (q15_t*)gFFTOutput1, FFT_SIZE);
    
    arm_max_q15((q15_t*)&gFFTOutput1[1], FFT_SIZE/2 - 1, (q15_t*)&gFFTmaxValue1, &gFFTmaxFreqIndex1);
    gFFTmaxFreqIndex1 += 1;
    
    gRealAmplitude1 = calculate_real_amplitude(gFFTmaxValue1);
    
    int16_t real1 = gFFTInput1[2 * gFFTmaxFreqIndex1];
    int16_t imag1 = gFFTInput1[2 * gFFTmaxFreqIndex1 + 1];
    gPhase1_FFT = calculate_phase_fft(real1, imag1);
    
    gPhaseDiff_FFT = calculate_phase_difference(gPhase0_FFT, gPhase1_FFT);
}

float calculate_phase_fft(int16_t real, int16_t imag)
{
    if (real == 0 && imag == 0) {
        return 0.0f;
    }
    return atan2f((float)imag, (float)real);
}