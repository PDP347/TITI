/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include "arm_const_structs.h"
#include "arm_math.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* FFT configuration */
#define FFT_SIZE (256)
#define ADC_SAMPLE_SIZE (500)

/* FFT defines */
#define IFFTFLAG 0
#define BITREVERSE 1

/* ADC reference voltage and resolution */
#define ADC_VREF (3.3f)          // ADC参考电压 (V)
#define ADC_RESOLUTION (4096)    // 12位ADC分辨率 (2^12)

/* ADC sample buffers */
uint16_t gADC0Samples[ADC_SAMPLE_SIZE];
uint16_t gADC1Samples[ADC_SAMPLE_SIZE];
volatile bool gCheckADC0;
volatile bool gCheckADC1;

/* FFT buffers - need to be complex (real + imaginary) */
volatile int16_t gFFTInput0[FFT_SIZE * 2];   // ADC0 FFT input buffer
volatile int16_t gFFTInput1[FFT_SIZE * 2];   // ADC1 FFT input buffer
volatile int16_t gFFTOutput0[FFT_SIZE];      // ADC0 FFT magnitude output
volatile int16_t gFFTOutput1[FFT_SIZE];      // ADC1 FFT magnitude output

/* FFT results */
volatile uint32_t gFFTmaxValue0, gFFTmaxValue1;
volatile uint32_t gFFTmaxFreqIndex0, gFFTmaxFreqIndex1;

/* Phase calculation */
volatile float gPhase0;                      // ADC0相位
volatile float gPhase1;                      // ADC1相位
volatile float gPhaseDiff;                   // 相位差

/* Real amplitude calculation */
volatile float gRealAmplitude0;              // ADC0真实幅值 (V)
volatile float gRealAmplitude1;              // ADC1真实幅值 (V)

// UART发送缓冲区
char uart_buffer[256];

// 函数声明
void UART_send_string(const char* str);
void configure_adc_dma(void);
void perform_fft_analysis(void);
void prepare_fft_data(uint16_t* adc_samples, int16_t* fft_input, uint16_t offset);
void output_fft_results(void);
float calculate_dc_offset(uint16_t* samples, uint16_t start, uint16_t count);
float calculate_phase(int16_t real, int16_t imag);
float calculate_real_amplitude(uint32_t fft_magnitude);
float calculate_phase_difference(float phase1, float phase2);

int main(void)
{
    SYSCFG_DL_init();

    /* 初始化UART */
    UART_send_string("ADC Dual Channel FFT Analysis - Real Amplitude & Phase Difference\r\n");
    UART_send_string("Format: ADC0[Freq, Amplitude(V), Phase(deg)], ADC1[Freq, Amplitude(V), Phase(deg)], Phase Diff(deg)\r\n");
    UART_send_string("================================================================================\r\n");
    
    /* 配置ADC和DMA */
    configure_adc_dma();
    
    /* 添加延时确保ADC稳定 */
    DL_Common_delayCycles(100000);

    // 用于跟踪ADC数据是否准备就绪
    static bool adc0_ready = false;
    static bool adc1_ready = false;

    while (1) {
        if (gCheckADC0) {
            gCheckADC0 = false;
            adc0_ready = true;
            
            // 重新配置ADC DMA采样数
            DL_ADC12_setDMASamplesCnt(ADC12_0_INST, 1);
            
            // 重新配置DMA并启动下一轮采样
            DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
            DL_ADC12_startConversion(ADC12_0_INST);
        }
        
        if (gCheckADC1) {
            gCheckADC1 = false;
            adc1_ready = true;
            
            // 重新配置ADC DMA采样数
            DL_ADC12_setDMASamplesCnt(ADC12_1_INST, 1);
            
            // 重新配置DMA并启动下一轮采样
            DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);
            DL_ADC12_startConversion(ADC12_1_INST);
        }
        
        // 当两路都有新数据时，进行FFT分析
        if (adc0_ready && adc1_ready) {
            perform_fft_analysis();
            output_fft_results();
            
            adc0_ready = false;
            adc1_ready = false;
        }
    }
}

void configure_adc_dma(void)
{
    // 初始化标志
    gCheckADC0 = false;
    gCheckADC1 = false;
    
    /* 重新配置ADC DMA采样数 */
    DL_ADC12_setDMASamplesCnt(ADC12_0_INST, ADC_SAMPLE_SIZE);
    DL_ADC12_setDMASamplesCnt(ADC12_1_INST, ADC_SAMPLE_SIZE);
    
    /* 配置ADC12_0的DMA */
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_0_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);

    /* 配置ADC12_1的DMA */
    DL_DMA_setSrcAddr(DMA, DMA_CH1_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_1_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);

    /* 启用ADC中断 */
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    NVIC_EnableIRQ(ADC12_1_INST_INT_IRQN);
    
    /* 设置ADC中断优先级 */
    NVIC_SetPriority(ADC12_0_INST_INT_IRQN, 1);
    NVIC_SetPriority(ADC12_1_INST_INT_IRQN, 1);
    
    /* 清除任何待处理的中断 */
    DL_ADC12_clearInterruptStatus(ADC12_0_INST, DL_ADC12_INTERRUPT_DMA_DONE);
    DL_ADC12_clearInterruptStatus(ADC12_1_INST, DL_ADC12_INTERRUPT_DMA_DONE);

    /* 启动ADC转换 */
    DL_ADC12_startConversion(ADC12_0_INST);
    DL_ADC12_startConversion(ADC12_1_INST);
}

void ADC12_0_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_0_INST);
    
    switch (interruptStatus) {
        case DL_ADC12_IIDX_DMA_DONE:
            gCheckADC0 = true;
            break;
        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
            // 单次转换完成中断（如果需要的话）
            break;
        default:
            break;
    }
}

void ADC12_1_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_1_INST);
    
    switch (interruptStatus) {
        case DL_ADC12_IIDX_DMA_DONE:
            gCheckADC1 = true;
            break;
        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
            // 单次转换完成中断（如果需要的话）
            break;
        default:
            break;
    }
}

// UART发送字符串函数
void UART_send_string(const char* str)
{
    while (*str) {
        while (DL_UART_Main_isBusy(UART_0_INST));
        DL_UART_Main_transmitData(UART_0_INST, *str++);
    }
}

// 计算直流偏移（平均值）
float calculate_dc_offset(uint16_t* samples, uint16_t start, uint16_t count)
{
    uint32_t sum = 0;
    for (uint16_t i = start; i < start + count; i++) {
        sum += samples[i];
    }
    return (float)sum / count;
}

// 准备FFT数据：从ADC样本中提取FFT_SIZE个样本并转换为复数格式，同时去除直流偏移
void prepare_fft_data(uint16_t* adc_samples, int16_t* fft_input, uint16_t offset)
{
    // 计算要分析的样本段的直流偏移
    float dc_offset = calculate_dc_offset(adc_samples, offset, FFT_SIZE);
    
    // 从ADC样本中提取FFT_SIZE个样本，并去除直流偏移
    for (uint16_t i = 0; i < FFT_SIZE; i++) {
        // 去除直流偏移：样本值减去平均值
        int16_t sample = (int16_t)(adc_samples[i + offset] - dc_offset);
        
        // 复数格式：实部 + 虚部
        fft_input[2 * i] = sample;      // 实部
        fft_input[2 * i + 1] = 0;       // 虚部设为0
    }
}

// 计算真实幅值（电压值）
float calculate_real_amplitude(uint32_t fft_magnitude)
{
    // 将FFT幅值转换为真实电压幅值
    // FFT幅值需要除以FFT_SIZE/2来归一化（除了DC分量）
    // 然后乘以ADC分辨率系数将数字值转换为电压值
    float normalized_magnitude = (float)fft_magnitude / (FFT_SIZE / 2);
    float voltage_amplitude = (normalized_magnitude * ADC_VREF) / ADC_RESOLUTION;
    
    return voltage_amplitude;
}

// 计算相位差（phase2 - phase1）
float calculate_phase_difference(float phase1, float phase2)
{
    float diff = phase2 - phase1;
    
    // 将相位差限制在 -π 到 π 之间
    while (diff > M_PI) {
        diff -= 2 * M_PI;
    }
    while (diff < -M_PI) {
        diff += 2 * M_PI;
    }
    
    return diff;
}

// 执行FFT分析
void perform_fft_analysis(void)
{
    // 准备FFT输入数据
    prepare_fft_data(gADC0Samples, (int16_t*)gFFTInput0, 0);    // ADC0从位置0开始
    prepare_fft_data(gADC1Samples, (int16_t*)gFFTInput1, 0);    // ADC1从位置0开始
    
    // 执行FFT - ADC0
    arm_cfft_q15(&arm_cfft_sR_q15_len256, (q15_t*)gFFTInput0, IFFTFLAG, BITREVERSE);
    arm_cmplx_mag_q15((q15_t*)gFFTInput0, (q15_t*)gFFTOutput0, FFT_SIZE);
    
    // 忽略DC分量（bin 0），从bin 1开始寻找最大值
    arm_max_q15((q15_t*)&gFFTOutput0[1], FFT_SIZE/2 - 1, (q15_t*)&gFFTmaxValue0, &gFFTmaxFreqIndex0);
    gFFTmaxFreqIndex0 += 1; // 补偿因为从bin 1开始搜索
    
    // 计算ADC0的真实幅值
    gRealAmplitude0 = calculate_real_amplitude(gFFTmaxValue0);
    
    // 计算ADC0在峰值频率处的相位
    int16_t real0 = gFFTInput0[2 * gFFTmaxFreqIndex0];
    int16_t imag0 = gFFTInput0[2 * gFFTmaxFreqIndex0 + 1];
    gPhase0 = calculate_phase(real0, imag0);
    
    // 执行FFT - ADC1
    arm_cfft_q15(&arm_cfft_sR_q15_len256, (q15_t*)gFFTInput1, IFFTFLAG, BITREVERSE);
    arm_cmplx_mag_q15((q15_t*)gFFTInput1, (q15_t*)gFFTOutput1, FFT_SIZE);
    
    // 忽略DC分量（bin 0），从bin 1开始寻找最大值
    arm_max_q15((q15_t*)&gFFTOutput1[1], FFT_SIZE/2 - 1, (q15_t*)&gFFTmaxValue1, &gFFTmaxFreqIndex1);
    gFFTmaxFreqIndex1 += 1; // 补偿因为从bin 1开始搜索
    
    // 计算ADC1的真实幅值
    gRealAmplitude1 = calculate_real_amplitude(gFFTmaxValue1);
    
    // 计算ADC1在峰值频率处的相位
    int16_t real1 = gFFTInput1[2 * gFFTmaxFreqIndex1];
    int16_t imag1 = gFFTInput1[2 * gFFTmaxFreqIndex1 + 1];
    gPhase1 = calculate_phase(real1, imag1);
    
    // 计算相位差 (ADC1 - ADC0)
    gPhaseDiff = calculate_phase_difference(gPhase0, gPhase1);
}

// 输出FFT分析结果
void output_fft_results(void)
{
    // 假设采样频率为200kHz（根据您的ADC配置调整）
    float sampling_freq = 200000.0f;
    float freq_resolution = sampling_freq / FFT_SIZE;
    
    // 计算主要频率成分
    float dominant_freq0 = gFFTmaxFreqIndex0 * freq_resolution;
    float dominant_freq1 = gFFTmaxFreqIndex1 * freq_resolution;
    
    // 将相位转换为度数
    float phase0_deg = gPhase0 * 180.0f / M_PI;
    float phase1_deg = gPhase1 * 180.0f / M_PI;
    float phase_diff_deg = gPhaseDiff * 180.0f / M_PI;
    
    // 输出结果：频率、真实幅值(V)、相位(度)和相位差
    sprintf(uart_buffer, "ADC0: %.1fHz, %.3fV, %.1frad  |  ADC1: %.1fHz, %.3fV, %.1frad  |  Phase Diff: %.1frad\r\n", 
            dominant_freq0, gRealAmplitude0, phase0_deg,
            dominant_freq1, gRealAmplitude1, phase1_deg,
            phase_diff_deg);
    UART_send_string(uart_buffer);
}

// 计算相位角
float calculate_phase(int16_t real, int16_t imag)
{
    if (real == 0 && imag == 0) {
        return 0.0f;
    }
    return atan2f((float)imag, (float)real);
}