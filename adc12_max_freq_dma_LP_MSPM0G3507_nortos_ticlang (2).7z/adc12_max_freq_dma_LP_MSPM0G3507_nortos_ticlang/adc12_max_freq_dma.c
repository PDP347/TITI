/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include <stdio.h>
#include <string.h>

#define ADC_SAMPLE_SIZE (1024)

uint16_t gADC0Samples[ADC_SAMPLE_SIZE];
uint16_t gADC1Samples[ADC_SAMPLE_SIZE];
volatile bool gCheckADC0;
volatile bool gCheckADC1;

// UART发送缓冲区
char uart_buffer[128];

// 函数声明
void UART_send_string(const char* str);
uint32_t calculate_average(uint16_t* samples, uint16_t size);
void process_adc_data(void);
void configure_adc_dma(void);

int main(void)
{
    SYSCFG_DL_init();

    /* 初始化UART */
    UART_send_string("ADC Dual Channel Sampling Started\r\n");
    UART_send_string("Format: ADC0_Avg, ADC1_Avg\r\n");
    
    /* 配置ADC和DMA */
    configure_adc_dma();
    
    /* 添加延时确保ADC稳定 */
    DL_Common_delayCycles(100000);

    // 用于跟踪ADC数据是否准备就绪
    static bool adc0_ready = false;
    static bool adc1_ready = false;

    while (1) {
        if (gCheckADC0) {
            gCheckADC0 = false;
            adc0_ready = true;
            
            // 重新配置ADC DMA采样数
            DL_ADC12_setDMASamplesCnt(ADC12_0_INST, 1);
            
            // 重新配置DMA并启动下一轮采样
            DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
            DL_ADC12_startConversion(ADC12_0_INST);
        }
        
        if (gCheckADC1) {
            gCheckADC1 = false;
            adc1_ready = true;
            
            // 重新配置ADC DMA采样数
            DL_ADC12_setDMASamplesCnt(ADC12_1_INST, 1);
            
            // 重新配置DMA并启动下一轮采样
            DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
            DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
            DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);
            DL_ADC12_startConversion(ADC12_1_INST);
        }
        
        // 当两路都有新数据时，进行数据处理和输出
        if (adc0_ready && adc1_ready) {
            process_adc_data();
            adc0_ready = false;
            adc1_ready = false;
        }
        
        // 可以取消注释以节省功耗
        // __WFI();
    }
}

void configure_adc_dma(void)
{
    // 初始化标志
    gCheckADC0 = false;
    gCheckADC1 = false;
    
    /* 重新配置ADC DMA采样数 */
    DL_ADC12_setDMASamplesCnt(ADC12_0_INST, ADC_SAMPLE_SIZE);
    DL_ADC12_setDMASamplesCnt(ADC12_1_INST, ADC_SAMPLE_SIZE);
    
    /* 配置ADC12_0的DMA */
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_0_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &gADC0Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);

    /* 配置ADC12_1的DMA */
    DL_DMA_setSrcAddr(DMA, DMA_CH1_CHAN_ID,
        (uint32_t) DL_ADC12_getMemResultAddress(ADC12_1_INST, DL_ADC12_MEM_IDX_0));
    DL_DMA_setDestAddr(DMA, DMA_CH1_CHAN_ID, (uint32_t) &gADC1Samples[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH1_CHAN_ID, ADC_SAMPLE_SIZE);
    DL_DMA_enableChannel(DMA, DMA_CH1_CHAN_ID);

    /* 启用ADC中断 */
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    NVIC_EnableIRQ(ADC12_1_INST_INT_IRQN);
    
    /* 设置ADC中断优先级 */
    NVIC_SetPriority(ADC12_0_INST_INT_IRQN, 1);
    NVIC_SetPriority(ADC12_1_INST_INT_IRQN, 1);
    
    /* 清除任何待处理的中断 */
    DL_ADC12_clearInterruptStatus(ADC12_0_INST, DL_ADC12_INTERRUPT_DMA_DONE);
    DL_ADC12_clearInterruptStatus(ADC12_1_INST, DL_ADC12_INTERRUPT_DMA_DONE);

    /* 启动ADC转换 */
    DL_ADC12_startConversion(ADC12_0_INST);
    DL_ADC12_startConversion(ADC12_1_INST);
}

void ADC12_0_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_0_INST);
    
    switch (interruptStatus) {
        case DL_ADC12_IIDX_DMA_DONE:
            gCheckADC0 = true;
            break;
        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
            // 单次转换完成中断（如果需要的话）
            break;
        default:
            break;
    }
}

void ADC12_1_INST_IRQHandler(void)
{
    uint32_t interruptStatus = DL_ADC12_getPendingInterrupt(ADC12_1_INST);
    
    switch (interruptStatus) {
        case DL_ADC12_IIDX_DMA_DONE:
            gCheckADC1 = true;
            break;
        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
            // 单次转换完成中断（如果需要的话）
            break;
        default:
            break;
    }
}

// UART发送字符串函数
void UART_send_string(const char* str)
{
    while (*str) {
        while (DL_UART_Main_isBusy(UART_0_INST));
        DL_UART_Main_transmitData(UART_0_INST, *str++);
    }
}

// 计算平均值函数
uint32_t calculate_average(uint16_t* samples, uint16_t size)
{
    uint32_t sum = 0;
    for (uint16_t i = 0; i < size; i++) {
        sum += samples[i];
    }
    return sum / size;
}

// 处理ADC数据并通过UART输出
void process_adc_data(void)
{
    uint32_t adc0_avg = calculate_average(gADC0Samples, ADC_SAMPLE_SIZE);
    uint32_t adc1_avg = calculate_average(gADC1Samples, ADC_SAMPLE_SIZE);
    
    // 格式化输出字符串
    sprintf(uart_buffer, "ADC0_Avg: %lu, ADC1_Avg: %lu\r\n", adc0_avg, adc1_avg);
    UART_send_string(uart_buffer);
    
    // 可选：输出电压值（假设参考电压为3.3V，12位ADC）
    float adc0_voltage = (adc0_avg * 3.3f) / 4095.0f;
    float adc1_voltage = (adc1_avg * 3.3f) / 4095.0f;
    
    sprintf(uart_buffer, "ADC0_Voltage: %.3fV, ADC1_Voltage: %.3fV\r\n", 
            adc0_voltage, adc1_voltage);
    UART_send_string(uart_buffer);
    
    // 添加分隔线便于阅读
    UART_send_string("--------------------\r\n");
}