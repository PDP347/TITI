/*
 * ADC采样最大值显示程序（优化版）
 * 只显示和刷新ADC采样的最大值
 */

#include "ti_msp_dl_config.h"
#include "st7789.h"
#include <stdio.h>
#include <string.h>

#define FFT_LENGTH 1024

// 使用volatile关键字确保编译器不优化这些变量
volatile uint16_t gSamples_ADC[FFT_LENGTH] = {0};
volatile uint16_t gCheckADC = 0;
volatile uint16_t gMaxValue = 0;

// 查找数组中的最大值 - 优化版本
static uint16_t find_max_value(volatile uint16_t* data, uint16_t length)
{
    uint16_t max = data[0];
    uint16_t current;
    
    // 展开循环提高效率，每次处理4个元素
    uint16_t i = 1;
    for(; i < (length & ~3); i += 4)
    {
        current = data[i];
        if(current > max) max = current;
        
        current = data[i+1];
        if(current > max) max = current;
        
        current = data[i+2];
        if(current > max) max = current;
        
        current = data[i+3];
        if(current > max) max = current;
    }
    
    // 处理剩余元素
    for(; i < length; i++)
    {
        current = data[i];
        if(current > max) max = current;
    }
    
    return max;
}

int main(void)
{
    // 系统初始化
    SYSCFG_DL_init();

    // 配置DMA传输地址
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)&ADC12_0_INST->ULLMEM.MEMRES[0]);
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)&gSamples_ADC[0]);
    
    // 启用ADC中断
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    
    // 初始化状态
    gCheckADC = 1;
    gMaxValue = 0;

    // 启动DMA和定时器
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
    DL_TimerG_startCounter(TIMER_0_INST);
    
    while (1) {
        // 检查是否有新的采样数据
        if (gCheckADC == 0) {
            // 查找当前采样数据的最大值
            gMaxValue = find_max_value(gSamples_ADC, FFT_LENGTH);
            
            // 标记数据已处理，等待下一轮采样完成
            gCheckADC = 1;
        }
        
        // 使用更短的延时或者进入低功耗模式
        __WFI();  // 等待中断，节省功耗
    }
}

void ADC12_0_INST_IRQHandler(void)
{
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
        case DL_ADC12_IIDX_DMA_DONE:
            // 标记新数据可用
            gCheckADC = 0;
            break;
        default:
            break;
    }
}