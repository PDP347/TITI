/*
 * ST7789 硬件接口实现 - MSPM0G3507平台
 * 
 * 需要在CCS中配置以下引脚：
 * - SPI接口 (MOSI, SCK)
 * - CS (片选)
 * - DC (数据/命令选择)
 * - RST (复位)
 * - BLK (背光控制，可选)
 */

/*
 * ST7789 硬件接口实现 - MSPM0G3507平台
 * 更新以匹配生成的配置文件
 */

#include "st7789.h"
#include "ti_msp_dl_config.h"

// GPIO初始化
void ST7789_GPIO_Init(void)
{
    // GPIO初始化已在ti_msp_dl_config中完成
    // 这里可以添加额外的初始化代码
}

// 片选控制
void ST7789_CS_Set(uint8_t state)
{
    if (state)
    {
        // CS高电平
        DL_GPIO_setPins(GPIO_screen_PORT, GPIO_screen_CS0_PIN);
    }
    else
    {
        // CS低电平
        DL_GPIO_clearPins(GPIO_screen_PORT, GPIO_screen_CS0_PIN);
    }
}

// 数据/命令选择控制
void ST7789_DC_Set(uint8_t state)
{
    if (state)
    {
        // DC高电平 (数据)
        DL_GPIO_setPins(SCREEN_DC_PORT, SCREEN_DC_PIN_0_PIN);
    }
    else
    {
        // DC低电平 (命令)
        DL_GPIO_clearPins(SCREEN_DC_PORT, SCREEN_DC_PIN_0_PIN);
    }
}

// 复位控制
void ST7789_RST_Set(uint8_t state)
{
    if (state)
    {
        // RST高电平
        DL_GPIO_setPins(SCREEN_RST_PORT, SCREEN_RST_PIN_1_PIN);
    }
    else
    {
        // RST低电平
        DL_GPIO_clearPins(SCREEN_RST_PORT, SCREEN_RST_PIN_1_PIN);
    }
}

// 背光控制
void ST7789_BLK_Set(uint8_t state)
{
    // 如果您需要背光控制，请在SysConfig中添加相应的GPIO配置
    (void)state; // 占位，避免未使用参数告警
}

// SPI写字节
void ST7789_SPI_WriteByte(uint8_t data)
{
    // 等待发送缓冲区空
    while (!DL_SPI_isTXFIFOEmpty(screen_INST))
        ;

    // 发送数据
    DL_SPI_transmitData8(screen_INST, data);

    // 等待传输完成
    while (DL_SPI_isBusy(screen_INST))
        ;
}

// 延时函数 (毫秒)
void ST7789_Delay_ms(uint32_t ms)
{
    // 基于32MHz系统时钟的延时
    uint32_t i, j;
    for (i = 0; i < ms; i++)
    {
        for (j = 0; j < 8000; j++)
        { // 约1ms的延时循环
            __NOP();
        }
    }
}