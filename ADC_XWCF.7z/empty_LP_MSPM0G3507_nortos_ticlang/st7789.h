#ifndef __ST7789_H__
#define __ST7789_H__

#include <stdint.h>
#include <stdbool.h>

// 屏幕参数定义
#define ST7789_WIDTH          240
#define ST7789_HEIGHT         320
#define ST7789_ROTATION       0       // 0-3: 屏幕旋转角度 0/90/180/270

// 颜色定义 (RGB565格式)
#define BLACK                 0x0000
#define WHITE                 0xFFFF
#define RED                   0xF800
#define GREEN                 0x07E0
#define BLUE                  0x001F
#define YELLOW                0xFFE0
#define CYAN                  0x07FF
#define MAGENTA               0xF81F
#define GRAY                  0x8410
#define DARK_GRAY             0x4208
#define LIGHT_GRAY            0xC618
#define ORANGE                0xFD20
#define PINK                  0xF81F

// ST7789命令定义
#define ST7789_NOP            0x00
#define ST7789_SWRESET        0x01
#define ST7789_RDDID          0x04
#define ST7789_RDDST          0x09
#define ST7789_SLPIN          0x10
#define ST7789_SLPOUT         0x11
#define ST7789_PTLON          0x12
#define ST7789_NORON          0x13
#define ST7789_INVOFF         0x20
#define ST7789_INVON          0x21
#define ST7789_DISPOFF        0x28
#define ST7789_DISPON         0x29
#define ST7789_CASET          0x2A
#define ST7789_RASET          0x2B
#define ST7789_RAMWR          0x2C
#define ST7789_RAMRD          0x2E
#define ST7789_PTLAR          0x30
#define ST7789_VSCRDEF        0x33
#define ST7789_COLMOD         0x3A
#define ST7789_MADCTL         0x36
#define ST7789_VSCRSADD       0x37

// MADCTL位定义
#define MADCTL_MY             0x80
#define MADCTL_MX             0x40
#define MADCTL_MV             0x20
#define MADCTL_ML             0x10
#define MADCTL_RGB            0x00
#define MADCTL_BGR            0x08
#define MADCTL_MH             0x04

// 字体大小定义
typedef enum {
    FONT_SIZE_12 = 12,
    FONT_SIZE_16 = 16,
    FONT_SIZE_24 = 24
} FontSize;

// 接口函数声明 (需要用户实现)
void ST7789_GPIO_Init(void);
void ST7789_CS_Set(uint8_t state);
void ST7789_DC_Set(uint8_t state);
void ST7789_RST_Set(uint8_t state);
void ST7789_BLK_Set(uint8_t state);
void ST7789_SPI_WriteByte(uint8_t data);
void ST7789_Delay_ms(uint32_t ms);

// ST7789驱动函数声明
void ST7789_WriteCommand(uint8_t cmd);
void ST7789_WriteData(uint8_t data);
void ST7789_WriteData16(uint16_t data);
void ST7789_Init(void);
void ST7789_SetRotation(uint8_t rotation);
void ST7789_SetWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
void ST7789_Clear(uint16_t color);
void ST7789_DrawPixel(uint16_t x, uint16_t y, uint16_t color);
void ST7789_DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color);
void ST7789_DrawRectangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color);
void ST7789_FillRectangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color);
void ST7789_DrawCircle(uint16_t x0, uint16_t y0, uint16_t r, uint16_t color);
void ST7789_FillCircle(uint16_t x0, uint16_t y0, uint16_t r, uint16_t color);
void ST7789_DrawChar(uint16_t x, uint16_t y, char ch, uint16_t color, uint16_t bg_color, FontSize font_size);
void ST7789_DrawString(uint16_t x, uint16_t y, const char* str, uint16_t color, uint16_t bg_color, FontSize font_size);
void ST7789_DrawBitmap(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint16_t* bitmap);
void ST7789_SetBacklight(uint8_t brightness);
void ST7789_DisplayOn(void);
void ST7789_DisplayOff(void);
void ST7789_InvertColors(bool invert);

// 获取屏幕尺寸
uint16_t ST7789_GetWidth(void);
uint16_t ST7789_GetHeight(void);

// 绘制折线图（横屏模式下使用）
void ST7789_DrawGraph(const int16_t* data, uint16_t count, int16_t y_min, int16_t y_max, uint16_t color);
void ST7789_DrawGraphArea(const int16_t* data, uint16_t count, int16_t y_min, int16_t y_max,
                          uint16_t color, uint16_t x0, uint16_t y0, uint16_t w, uint16_t h,
                          bool draw_axes);

#endif // __ST7789_H__ 