#include "st7789.h"
#include <stdlib.h>
#include <string.h>

// 当前屏幕参数
static uint16_t screen_width = ST7789_WIDTH;
static uint16_t screen_height = ST7789_HEIGHT;
static uint8_t screen_rotation = ST7789_ROTATION;

// 基础字体 (ASCII 5x8)
static const uint8_t font_5x8[96][5] = {
    {0x00,0x00,0x00,0x00,0x00}, // 0x20 ' '
    {0x00,0x00,0x5F,0x00,0x00}, // 0x21 '!'
    {0x00,0x07,0x00,0x07,0x00}, // 0x22 '"'
    {0x14,0x7F,0x14,0x7F,0x14}, // 0x23 '#'
    {0x24,0x2A,0x7F,0x2A,0x12}, // 0x24 '$'
    {0x23,0x13,0x08,0x64,0x62}, // 0x25 '%'
    {0x36,0x49,0x55,0x22,0x50}, // 0x26 '&'
    {0x00,0x05,0x03,0x00,0x00}, // 0x27 '''
    {0x00,0x1C,0x22,0x41,0x00}, // 0x28 '('
    {0x00,0x41,0x22,0x1C,0x00}, // 0x29 ')'
    {0x14,0x08,0x3E,0x08,0x14}, // 0x2A '*'
    
    {0x08,0x08,0x3E,0x08,0x08}, // 0x2B '+'
    {0x00,0x50,0x30,0x00,0x00}, // 0x2C ','
    {0x08,0x08,0x08,0x08,0x08}, // 0x2D '-'
    {0x00,0x60,0x60,0x00,0x00}, // 0x2E '.'
    {0x20,0x10,0x08,0x04,0x02}, // 0x2F '/'
    {0x3E,0x51,0x49,0x45,0x3E}, // 0x30 '0'
    {0x00,0x42,0x7F,0x40,0x00}, // 0x31 '1'
    {0x42,0x61,0x51,0x49,0x46}, // 0x32 '2'
    {0x21,0x41,0x45,0x4B,0x31}, // 0x33 '3'
    {0x18,0x14,0x12,0x7F,0x10}, // 0x34 '4'
    {0x27,0x45,0x45,0x45,0x39}, // 0x35 '5'
    {0x3C,0x4A,0x49,0x49,0x30}, // 0x36 '6'
    {0x01,0x71,0x09,0x05,0x03}, // 0x37 '7'
    {0x36,0x49,0x49,0x49,0x36}, // 0x38 '8'
    {0x06,0x49,0x49,0x29,0x1E}, // 0x39 '9'
    {0x00,0x36,0x36,0x00,0x00}, // 0x3A ':'
    {0x00,0x56,0x36,0x00,0x00}, // 0x3B ';'
    {0x08,0x14,0x22,0x41,0x00}, // 0x3C '<'
    {0x14,0x14,0x14,0x14,0x14}, // 0x3D '='
    {0x00,0x41,0x22,0x14,0x08}, // 0x3E '>'
    {0x02,0x01,0x51,0x09,0x06}, // 0x3F '?'
    {0x32,0x49,0x79,0x41,0x3E}, // 0x40 '@'
    {0x7E,0x11,0x11,0x11,0x7E}, // 0x41 'A'
    {0x7F,0x49,0x49,0x49,0x36}, // 0x42 'B'
    {0x3E,0x41,0x41,0x41,0x22}, // 0x43 'C'
    {0x7F,0x41,0x41,0x22,0x1C}, // 0x44 'D'
    {0x7F,0x49,0x49,0x49,0x41}, // 0x45 'E'
    {0x7F,0x09,0x09,0x09,0x01}, // 0x46 'F'
    {0x3E,0x41,0x49,0x49,0x7A}, // 0x47 'G'
    {0x7F,0x08,0x08,0x08,0x7F}, // 0x48 'H'
    {0x00,0x41,0x7F,0x41,0x00}, // 0x49 'I'
    {0x20,0x40,0x41,0x3F,0x01}, // 0x4A 'J'
    {0x7F,0x08,0x14,0x22,0x41}, // 0x4B 'K'
    {0x7F,0x40,0x40,0x40,0x40}, // 0x4C 'L'
    {0x7F,0x02,0x0C,0x02,0x7F}, // 0x4D 'M'
    {0x7F,0x04,0x08,0x10,0x7F}, // 0x4E 'N'
    {0x3E,0x41,0x41,0x41,0x3E}, // 0x4F 'O'
    {0x7F,0x09,0x09,0x09,0x06}, // 0x50 'P'
    {0x3E,0x41,0x51,0x21,0x5E}, // 0x51 'Q'
    {0x7F,0x09,0x19,0x29,0x46}, // 0x52 'R'
    {0x46,0x49,0x49,0x49,0x31}, // 0x53 'S'
    {0x01,0x01,0x7F,0x01,0x01}, // 0x54 'T'
    {0x3F,0x40,0x40,0x40,0x3F}, // 0x55 'U'
    {0x1F,0x20,0x40,0x20,0x1F}, // 0x56 'V'
    {0x7F,0x20,0x18,0x20,0x7F}, // 0x57 'W'
    {0x63,0x14,0x08,0x14,0x63}, // 0x58 'X'
    {0x03,0x04,0x78,0x04,0x03}, // 0x59 'Y'
    {0x61,0x51,0x49,0x45,0x43}, // 0x5A 'Z'
    {0x00,0x7F,0x41,0x41,0x00}, // 0x5B '['
    {0x02,0x04,0x08,0x10,0x20}, // 0x5C '\'
    {0x00,0x41,0x41,0x7F,0x00}, // 0x5D ']'
    {0x04,0x02,0x01,0x02,0x04}, // 0x5E '^'
    {0x40,0x40,0x40,0x40,0x40}, // 0x5F '_'
    {0x00,0x03,0x05,0x00,0x00}, // 0x60 '`'
    {0x20,0x54,0x54,0x54,0x78}, // 0x61 'a'
    {0x7F,0x48,0x44,0x44,0x38}, // 0x62 'b'
    {0x38,0x44,0x44,0x44,0x20}, // 0x63 'c'
    {0x38,0x44,0x44,0x48,0x7F}, // 0x64 'd'
    {0x38,0x54,0x54,0x54,0x18}, // 0x65 'e'
    {0x08,0x7E,0x09,0x01,0x02}, // 0x66 'f'
    {0x0C,0x52,0x52,0x52,0x3E}, // 0x67 'g'
    {0x7F,0x08,0x04,0x04,0x78}, // 0x68 'h'
    {0x00,0x44,0x7D,0x40,0x00}, // 0x69 'i'
    {0x20,0x40,0x44,0x3D,0x00}, // 0x6A 'j'
    {0x7F,0x10,0x28,0x44,0x00}, // 0x6B 'k'
    {0x00,0x41,0x7F,0x40,0x00}, // 0x6C 'l'
    {0x7C,0x04,0x18,0x04,0x78}, // 0x6D 'm'
    {0x7C,0x08,0x04,0x04,0x78}, // 0x6E 'n'
    {0x38,0x44,0x44,0x44,0x38}, // 0x6F 'o'
    {0x7C,0x14,0x14,0x14,0x08}, // 0x70 'p'
    {0x08,0x14,0x14,0x18,0x7C}, // 0x71 'q'
    {0x7C,0x08,0x04,0x04,0x08}, // 0x72 'r'
    {0x48,0x54,0x54,0x54,0x20}, // 0x73 's'
    {0x04,0x3F,0x44,0x40,0x20}, // 0x74 't'
    {0x3C,0x40,0x40,0x20,0x7C}, // 0x75 'u'
    {0x1C,0x20,0x40,0x20,0x1C}, // 0x76 'v'
    {0x3C,0x40,0x30,0x40,0x3C}, // 0x77 'w'
    {0x44,0x28,0x10,0x28,0x44}, // 0x78 'x'
    {0x0C,0x50,0x50,0x50,0x3C}, // 0x79 'y'
    {0x44,0x64,0x54,0x4C,0x44}, // 0x7A 'z'
    {0x00,0x08,0x36,0x41,0x00}, // 0x7B '{'
    {0x00,0x00,0x7F,0x00,0x00}, // 0x7C '|'
    {0x00,0x41,0x36,0x08,0x00}, // 0x7D '}'
    {0x10,0x08,0x08,0x10,0x08}  // 0x7E '~'
};

// 写命令
void ST7789_WriteCommand(uint8_t cmd) {
    ST7789_CS_Set(0);
    ST7789_DC_Set(0);
    ST7789_SPI_WriteByte(cmd);
    ST7789_CS_Set(1);
}

// 写8位数据
void ST7789_WriteData(uint8_t data) {
    ST7789_CS_Set(0);
    ST7789_DC_Set(1);
    ST7789_SPI_WriteByte(data);
    ST7789_CS_Set(1);
}

// 写16位数据
void ST7789_WriteData16(uint16_t data) {
    ST7789_CS_Set(0);
    ST7789_DC_Set(1);
    ST7789_SPI_WriteByte(data >> 8);  // 高字节先发
    ST7789_SPI_WriteByte(data & 0xFF);
    ST7789_CS_Set(1);
}

// 初始化ST7789
void ST7789_Init(void) {
    // 初始化GPIO
    ST7789_GPIO_Init();
    
    // 硬件复位
    ST7789_RST_Set(1);
    ST7789_Delay_ms(10);
    ST7789_RST_Set(0);
    ST7789_Delay_ms(10);
    ST7789_RST_Set(1);
    ST7789_Delay_ms(120);
    
    // 软件复位
    ST7789_WriteCommand(ST7789_SWRESET);
    ST7789_Delay_ms(150);
    
    // 退出睡眠模式
    ST7789_WriteCommand(ST7789_SLPOUT);
    ST7789_Delay_ms(120);
    
    // 颜色模式设置 (16位色)
    ST7789_WriteCommand(ST7789_COLMOD);
    ST7789_WriteData(0x55);
    
    // 根据默认旋转值设置 MADCTL
    ST7789_SetRotation(screen_rotation);
    
    // 列地址设置
    ST7789_WriteCommand(ST7789_CASET);
    ST7789_WriteData(0x00);
    ST7789_WriteData(0x00);
    ST7789_WriteData((ST7789_WIDTH - 1) >> 8);
    ST7789_WriteData((ST7789_WIDTH - 1) & 0xFF);
    
    // 行地址设置
    ST7789_WriteCommand(ST7789_RASET);
    ST7789_WriteData(0x00);
    ST7789_WriteData(0x00);
    ST7789_WriteData((ST7789_HEIGHT - 1) >> 8);
    ST7789_WriteData((ST7789_HEIGHT - 1) & 0xFF);
    
    // 正常显示模式（开启颜色反转）
    ST7789_WriteCommand(ST7789_INVON);
    ST7789_WriteCommand(ST7789_NORON);
    ST7789_Delay_ms(10);
    
    // 开启显示
    ST7789_WriteCommand(ST7789_DISPON);
    ST7789_Delay_ms(120);
    
    // 开启背光
    ST7789_BLK_Set(1);
    
    // 清屏
    ST7789_Clear(BLACK);
}

// 设置屏幕旋转
void ST7789_SetRotation(uint8_t rotation) {
    uint8_t madctl = 0;
    uint8_t color_bits = MADCTL_RGB; // 使用RGB顺序
    
    screen_rotation = rotation % 4;
    
    switch (screen_rotation) {
        case 0:
            madctl = MADCTL_MX | MADCTL_MY | color_bits;
            screen_width = ST7789_WIDTH;
            screen_height = ST7789_HEIGHT;
            break;
        case 1:
            madctl = MADCTL_MY | MADCTL_MV | color_bits;
            screen_width = ST7789_HEIGHT;
            screen_height = ST7789_WIDTH;
            break;
        case 2:
            madctl = color_bits;
            screen_width = ST7789_WIDTH;
            screen_height = ST7789_HEIGHT;
            break;
        case 3:
            madctl = MADCTL_MX | MADCTL_MV | color_bits;
            screen_width = ST7789_HEIGHT;
            screen_height = ST7789_WIDTH;
            break;
    }
    
    ST7789_WriteCommand(ST7789_MADCTL);
    ST7789_WriteData(madctl);
}

// 设置绘制窗口
void ST7789_SetWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    ST7789_WriteCommand(ST7789_CASET);
    ST7789_WriteData(x0 >> 8);
    ST7789_WriteData(x0 & 0xFF);
    ST7789_WriteData(x1 >> 8);
    ST7789_WriteData(x1 & 0xFF);
    
    ST7789_WriteCommand(ST7789_RASET);
    ST7789_WriteData(y0 >> 8);
    ST7789_WriteData(y0 & 0xFF);
    ST7789_WriteData(y1 >> 8);
    ST7789_WriteData(y1 & 0xFF);
    
    ST7789_WriteCommand(ST7789_RAMWR);
}

// 清屏
void ST7789_Clear(uint16_t color) {
    ST7789_SetWindow(0, 0, screen_width - 1, screen_height - 1);
    
    ST7789_CS_Set(0);
    ST7789_DC_Set(1);
    
    for (uint32_t i = 0; i < (uint32_t)screen_width * screen_height; i++) {
        ST7789_SPI_WriteByte(color >> 8);
        ST7789_SPI_WriteByte(color & 0xFF);
    }
    
    ST7789_CS_Set(1);
}

// 画点
void ST7789_DrawPixel(uint16_t x, uint16_t y, uint16_t color) {
    if (x >= screen_width || y >= screen_height) return;
    
    ST7789_SetWindow(x, y, x, y);
    ST7789_WriteData16(color);
}

// 画线 (Bresenham算法)
void ST7789_DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color) {
    int16_t dx = abs(x1 - x0);
    int16_t dy = abs(y1 - y0);
    int16_t sx = (x0 < x1) ? 1 : -1;
    int16_t sy = (y0 < y1) ? 1 : -1;
    int16_t err = dx - dy;
    
    while (1) {
        ST7789_DrawPixel(x0, y0, color);
        
        if (x0 == x1 && y0 == y1) break;
        
        int16_t e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x0 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y0 += sy;
        }
    }
}

// 画矩形
void ST7789_DrawRectangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color) {
    ST7789_DrawLine(x0, y0, x1, y0, color);
    ST7789_DrawLine(x1, y0, x1, y1, color);
    ST7789_DrawLine(x1, y1, x0, y1, color);
    ST7789_DrawLine(x0, y1, x0, y0, color);
}

// 填充矩形
void ST7789_FillRectangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color) {
    if (x0 > x1) { uint16_t temp = x0; x0 = x1; x1 = temp; }
    if (y0 > y1) { uint16_t temp = y0; y0 = y1; y1 = temp; }
    
    if (x1 >= screen_width) x1 = screen_width - 1;
    if (y1 >= screen_height) y1 = screen_height - 1;
    
    ST7789_SetWindow(x0, y0, x1, y1);
    
    ST7789_CS_Set(0);
    ST7789_DC_Set(1);
    
    uint32_t pixels = (x1 - x0 + 1) * (y1 - y0 + 1);
    for (uint32_t i = 0; i < pixels; i++) {
        ST7789_SPI_WriteByte(color >> 8);
        ST7789_SPI_WriteByte(color & 0xFF);
    }
    
    ST7789_CS_Set(1);
}

// 画圆
void ST7789_DrawCircle(uint16_t x0, uint16_t y0, uint16_t r, uint16_t color) {
    int16_t f = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x = 0;
    int16_t y = r;
    
    ST7789_DrawPixel(x0, y0 + r, color);
    ST7789_DrawPixel(x0, y0 - r, color);
    ST7789_DrawPixel(x0 + r, y0, color);
    ST7789_DrawPixel(x0 - r, y0, color);
    
    while (x < y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;
        
        ST7789_DrawPixel(x0 + x, y0 + y, color);
        ST7789_DrawPixel(x0 - x, y0 + y, color);
        ST7789_DrawPixel(x0 + x, y0 - y, color);
        ST7789_DrawPixel(x0 - x, y0 - y, color);
        ST7789_DrawPixel(x0 + y, y0 + x, color);
        ST7789_DrawPixel(x0 - y, y0 + x, color);
        ST7789_DrawPixel(x0 + y, y0 - x, color);
        ST7789_DrawPixel(x0 - y, y0 - x, color);
    }
}

// 填充圆
void ST7789_FillCircle(uint16_t x0, uint16_t y0, uint16_t r, uint16_t color) {
    int16_t f = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x = 0;
    int16_t y = r;
    
    ST7789_DrawLine(x0 - r, y0, x0 + r, y0, color);
    
    while (x < y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;
        
        ST7789_DrawLine(x0 - x, y0 + y, x0 + x, y0 + y, color);
        ST7789_DrawLine(x0 - x, y0 - y, x0 + x, y0 - y, color);
        ST7789_DrawLine(x0 - y, y0 + x, x0 + y, y0 + x, color);
        ST7789_DrawLine(x0 - y, y0 - x, x0 + y, y0 - x, color);
    }
}

// 画字符
void ST7789_DrawChar(uint16_t x, uint16_t y, char ch, uint16_t color, uint16_t bg_color, FontSize font_size) {
    // 超出范围的字符显示为空格
    if (ch < 32 || ch > 126) {
        ch = ' ';
    }

    uint8_t char_index = ch - 32;
    uint8_t scale = font_size / 8;
    
    for (uint8_t i = 0; i < 5; i++) {
        uint8_t line = font_5x8[char_index][i];
        for (uint8_t j = 0; j < 8; j++) {
            if (line & 0x01) {
                ST7789_FillRectangle(x + i * scale, y + j * scale, 
                                   x + (i + 1) * scale - 1, y + (j + 1) * scale - 1, color);
            } else if (bg_color != color) {
                ST7789_FillRectangle(x + i * scale, y + j * scale, 
                                   x + (i + 1) * scale - 1, y + (j + 1) * scale - 1, bg_color);
            }
            line >>= 1;
        }
    }

    // 绘制字符间隔空白列
    if (bg_color != color) {
        uint8_t i = 5; // 第6列为空白
        for (uint8_t j = 0; j < 8; j++) {
            ST7789_FillRectangle(x + i * scale, y + j * scale,
                               x + (i + 1) * scale - 1, y + (j + 1) * scale - 1, bg_color);
        }
    }
}

// 画字符串
void ST7789_DrawString(uint16_t x, uint16_t y, const char* str, uint16_t color, uint16_t bg_color, FontSize font_size) {
    uint8_t scale = font_size / 8;
    uint16_t x_pos = x;
    
    while (*str) {
        if (*str == '\n') {
            y += font_size;
            x_pos = x;
        } else {
            ST7789_DrawChar(x_pos, y, *str, color, bg_color, font_size);
            x_pos += 6 * scale;
        }
        str++;
    }
}

// 显示位图
void ST7789_DrawBitmap(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint16_t* bitmap) {
    if (x + w > screen_width || y + h > screen_height) return;
    
    ST7789_SetWindow(x, y, x + w - 1, y + h - 1);
    
    ST7789_CS_Set(0);
    ST7789_DC_Set(1);
    
    for (uint32_t i = 0; i < (uint32_t)w * h; i++) {
        ST7789_SPI_WriteByte(bitmap[i] >> 8);
        ST7789_SPI_WriteByte(bitmap[i] & 0xFF);
    }
    
    ST7789_CS_Set(1);
}

// 设置背光亮度 (0-100)
void ST7789_SetBacklight(uint8_t brightness) {
    // 简单的开关控制，可根据硬件支持改为PWM控制
    if (brightness > 0) {
        ST7789_BLK_Set(1);
    } else {
        ST7789_BLK_Set(0);
    }
}

// 开启显示
void ST7789_DisplayOn(void) {
    ST7789_WriteCommand(ST7789_DISPON);
}

// 关闭显示
void ST7789_DisplayOff(void) {
    ST7789_WriteCommand(ST7789_DISPOFF);
}

// 反色显示
void ST7789_InvertColors(bool invert) {
    ST7789_WriteCommand(invert ? ST7789_INVON : ST7789_INVOFF);
}

// 获取屏幕宽度
uint16_t ST7789_GetWidth(void) {
    return screen_width;
}

// 获取屏幕高度
uint16_t ST7789_GetHeight(void) {
    return screen_height;
}

// 绘制折线图
void ST7789_DrawGraph(const int16_t* data, uint16_t count, int16_t y_min, int16_t y_max, uint16_t color) {
    ST7789_DrawGraphArea(data, count, y_min, y_max, color, 0, 0, screen_width, screen_height, false);
}

// 绘制带坐标轴的折线图到指定区域
void ST7789_DrawGraphArea(const int16_t* data, uint16_t count, int16_t y_min, int16_t y_max,
                          uint16_t color, uint16_t x0, uint16_t y0, uint16_t w, uint16_t h,
                          bool draw_axes) {
    if (count < 2 || w == 0 || h == 0) return;

    if (y_max == y_min) y_max = y_min + 1;

    float x_scale = (float)(w - 1) / (count - 1);
    float y_scale = (float)(h - 1) / (y_max - y_min);

    // 轴
    if (draw_axes) {
        // y 轴
        ST7789_DrawLine(x0, y0, x0, y0 + h, WHITE);
        // x 轴：0 值对应的位置
        int16_t zero_pos = y0 + h - (int16_t)((0 - y_min) * y_scale);
        if (zero_pos >= y0 && zero_pos <= y0 + h) {
            ST7789_DrawLine(x0, zero_pos, x0 + w, zero_pos, WHITE);
        } else {
            // 默认在底部
            ST7789_DrawLine(x0, y0 + h, x0 + w, y0 + h, WHITE);
        }
    }

    uint16_t prev_x = x0;
    uint16_t prev_y = y0 + h - (uint16_t)((data[0] - y_min) * y_scale);
    for (uint16_t i = 1; i < count; i++) {
        uint16_t cur_x = x0 + (uint16_t)(i * x_scale);
        uint16_t cur_y = y0 + h - (uint16_t)((data[i] - y_min) * y_scale);
        ST7789_DrawLine(prev_x, prev_y, cur_x, cur_y, color);
        prev_x = cur_x;
        prev_y = cur_y;
    }
} 